"use strict";

import powerbi from "powerbi-visuals-api";
import { valueFormatter as vfUtils } from "powerbi-visuals-utils-formattingutils";

import { VisualFormattingSettingsModel } from "./settings";

/** 单个类别（柱子）在排序、累计后的完整信息 */
export interface ParetoDatum {
    /** scaleBand 的唯一键，避免类别名称重复导致 band 合并 */
    uid: string;
    /** 显示用类别名称 */
    label: string;
    /** 原始数值（空值为 null） */
    rawValue: number | null;
    /** 参与计算的数值（>= 0） */
    value: number;
    /** 降序排名，从 1 开始 */
    rank: number;
    /** 占总合计的比例，0 ~ 1 */
    share: number;
    /** 累计占比，0 ~ 1 */
    cumulative: number;
    /** 用于交叉筛选 / 工具提示 */
    selectionId: powerbi.extensibility.ISelectionId;
    /** 数据处理说明（例如负数按绝对值计入） */
    note: string;
}

/** 数据处理统计，用于右下角提示 */
export interface ParetoStats {
    blanks: number;
    negatives: number;
    droppedZeros: number;
}

export interface ParetoData {
    rows: ParetoDatum[];
    stats: ParetoStats;
    /** 合计是否有效（> 0）。为 false 时累计占比无意义 */
    hasTotal: boolean;
    total: number;
    formatValue: (value: number) => string;
    formatCategory: (value: powerbi.PrimitiveValue) => string;
}

function safeFormatter(
    format: string | undefined,
    locale: string,
    fallbackIsString: boolean
): vfUtils.IValueFormatter {
    try {
        return vfUtils.create({
            format: format || (fallbackIsString ? "g" : "#,0.###"),
            value: 0,
            cultureSelector: locale,
            allowFormatBeautification: true
        });
    } catch {
        return vfUtils.create({
            format: fallbackIsString ? "g" : "#,0.###",
            value: 0,
            cultureSelector: locale
        });
    }
}

/** 按固定小数位生成数值格式化函数（不走字段自带格式） */
export function createFixedFormatter(decimals: number, locale: string): (value: number) => string {
    const pattern = decimals > 0 ? `#,0.${"0".repeat(decimals)}` : "#,0";
    try {
        const formatter = vfUtils.create({
            format: pattern,
            value: 0,
            cultureSelector: locale,
            allowFormatBeautification: true
        });
        return (value: number) => String(formatter.format(value));
    } catch {
        return (value: number) => value.toFixed(decimals);
    }
}

/**
 * 从 DataView 抽取数据并完成帕累托计算。
 *
 * 空值 / 负数 / 0 值逻辑：
 *  - 空值（null / undefined / NaN）：按 blankHandling 处理，默认整行忽略。
 *  - 负数：按 negativeHandling 处理，默认忽略（既不计入合计也不显示）。
 *    这样合计 = 所有参与绘制柱子的数值之和，累计占比恒等于 100%。
 *  - 0 值：默认保留，绘制为基线细条，占比 0%，累计占比不受影响；
 *    关闭 showZeroBars 后整行移除（不参与排名与合计）。
 */
export function buildParetoData(
    dataView: powerbi.DataView,
    settings: VisualFormattingSettingsModel,
    host: powerbi.extensibility.visual.IVisualHost
): ParetoData | null {
    const categorical = dataView && dataView.categorical;
    if (!categorical || !categorical.categories || !categorical.categories.length) {
        return null;
    }
    if (!categorical.values || !categorical.values.length) {
        return null;
    }

    const categoryColumn = categorical.categories[0];
    const valueColumn = categorical.values[0];
    if (!categoryColumn || !categoryColumn.values) {
        return null;
    }

    const locale = (host && host.locale) || "zh-CN";
    const catFormatter = safeFormatter(categoryColumn.source && categoryColumn.source.format, locale, true);
    const valFormatter = safeFormatter(valueColumn.source && valueColumn.source.format, locale, false);

    const formatCategory = (value: powerbi.PrimitiveValue): string => {
        if (value === null || value === undefined) {
            return "(空白)";
        }
        try {
            return String(catFormatter.format(value));
        } catch {
            return String(value);
        }
    };

    const formatValue = (value: number): string => {
        try {
            return String(valFormatter.format(value));
        } catch {
            return String(value);
        }
    };

    const negativeMode = String(settings.dataHandling.negativeHandling.value.value || "ignore");
    const blankMode = String(settings.dataHandling.blankHandling.value.value || "ignore");
    const showZeroBars = settings.dataHandling.showZeroBars.value;

    const rawValues = valueColumn.values || [];
    const categoryValues = categoryColumn.values || [];
    const count = Math.max(rawValues.length, categoryValues.length);

    const selectionIdBuilder = host.createSelectionIdBuilder();

    interface Temp {
        uid: string;
        label: string;
        rawValue: number | null;
        value: number;
        index: number;
        selectionId: powerbi.extensibility.ISelectionId;
        note: string;
    }

    const temps: Temp[] = [];
    const stats: ParetoStats = { blanks: 0, negatives: 0, droppedZeros: 0 };

    for (let i = 0; i < count; i++) {
        const rawAny = rawValues[i] as powerbi.PrimitiveValue | undefined;
        const label = formatCategory(categoryValues[i]);

        let numeric: number | null = null;
        if (rawAny !== null && rawAny !== undefined) {
            const parsed = typeof rawAny === "number" ? rawAny : Number(rawAny);
            if (isFinite(parsed)) {
                numeric = parsed;
            }
        }

        let note = "";

        // 1) 空值
        if (numeric === null) {
            stats.blanks++;
            if (blankMode !== "zero") {
                continue;
            }
            numeric = 0;
            note = "空值按 0 计入";
        }

        // 2) 负数
        if (numeric < 0) {
            stats.negatives++;
            if (negativeMode === "absolute") {
                note = `原始值 ${formatValue(numeric)} 为负数，已按绝对值计入`;
                numeric = Math.abs(numeric);
            } else if (negativeMode === "zero") {
                note = `原始值 ${formatValue(numeric)} 为负数，已按 0 计入`;
                numeric = 0;
            } else {
                continue;
            }
        }

        // 3) 0 值
        if (numeric === 0 && !showZeroBars) {
            stats.droppedZeros++;
            continue;
        }

        temps.push({
            uid: `k${i}`,
            label,
            rawValue: rawAny === null || rawAny === undefined ? null : Number(rawAny),
            value: numeric,
            index: i,
            selectionId: selectionIdBuilder.withCategory(categoryColumn, i).createSelectionId(),
            note
        });
    }

    // 按值降序排序（稳定排序：值相同保持原始顺序）
    temps.sort((a, b) => (b.value - a.value) || (a.index - b.index));

    let total = 0;
    for (const t of temps) {
        total += t.value;
    }

    const hasTotal = isFinite(total) && total > 0;

    const rows: ParetoDatum[] = [];
    let running = 0;
    for (let i = 0; i < temps.length; i++) {
        const t = temps[i];
        running += t.value;
        rows.push({
            uid: t.uid,
            label: t.label,
            rawValue: t.rawValue,
            value: t.value,
            rank: i + 1,
            share: hasTotal ? t.value / total : 0,
            cumulative: hasTotal ? running / total : 0,
            selectionId: t.selectionId,
            note: t.note
        });
    }

    return {
        rows,
        stats,
        hasTotal,
        total,
        formatValue,
        formatCategory
    };
}
