import { Visual } from "../src/visual";

interface Row {
    category: string | null;
    value: number | null;
}

const rows: Row[] = [
    { category: "配件", value: 120 },
    { category: "自行车", value: 96 },
    { category: "服装", value: 78 },
    { category: "单车架", value: 55 },
    { category: "轮胎", value: 42 },
    { category: "头盔", value: 31 },
    { category: "水壶", value: 22 },
    { category: "鞋类", value: 14 },
    { category: "维修服务", value: 9 },
    { category: "退货", value: -18 },
    { category: "赠品", value: 0 },
    { category: "未知项", value: null }
];

function makeSelectionId(index: number) {
    return {
        getKey: () => `key-${index}`,
        equals: (other: any) => !!other && typeof other.getKey === "function" && other.getKey() === `key-${index}`,
        includes: () => false,
        getSelector: () => ({ data: [`0${index}`] }),
        hadIdentity: true
    };
}

function buildDataView(objects: any, data?: Row[]) {
    const source = data || rows;
    const categorySource = {
        displayName: "类别",
        queryName: "t.cat",
        roles: { category: true },
        type: { text: true }
    };
    const valueSource = {
        displayName: "值",
        queryName: "t.val",
        roles: { measure: true },
        type: { numeric: true },
        format: "#,0"
    };

    return {
        metadata: {
            columns: [categorySource, valueSource],
            objects: objects || {}
        },
        categorical: {
            categories: [
                {
                    source: categorySource,
                    values: source.map((r) => r.category)
                }
            ],
            values: [
                {
                    source: valueSource,
                    values: source.map((r) => r.value)
                }
            ]
        }
    };
}

const host: any = {
    locale: "zh-CN",
    eventService: {
        renderingStarted: () => undefined,
        renderingFinished: () => undefined,
        renderingFailed: () => undefined
    },
    tooltipService: {
        enabled: () => false,
        show: () => undefined,
        move: () => undefined,
        hide: () => undefined
    },
    createSelectionManager: () => ({
        hasSelection: () => false,
        getSelectionIds: () => [],
        select: () => ({ then: (cb: any) => cb([]) }),
        clear: () => ({ then: (cb: any) => cb([]) }),
        showContextMenu: () => undefined,
        registerOnSelectCallback: () => undefined
    }),
    createSelectionIdBuilder: () => {
        let index = 0;
        const builder: any = {
            withCategory: (_col: any, i: number) => {
                index = i;
                return builder;
            },
            withSeries: () => builder,
            withMeasure: () => builder,
            withMatrixNode: () => builder,
            withTable: () => builder,
            createSelectionId: () => makeSelectionId(index)
        };
        return builder;
    }
};

function color(hex: string) {
    return { solid: { color: hex } };
}

function renderCase(title: string, objects: any, size?: { w: number; h: number }, data?: Row[]) {
    const wrapper = document.createElement("section");
    wrapper.className = "case";

    const heading = document.createElement("h2");
    heading.textContent = title;
    wrapper.appendChild(heading);

    const width = size ? size.w : 780;
    const height = size ? size.h : 420;

    const box = document.createElement("div");
    box.className = "stage";
    box.style.width = `${width}px`;
    box.style.height = `${height}px`;
    wrapper.appendChild(box);

    const errorBox = document.createElement("pre");
    errorBox.className = "error";
    wrapper.appendChild(errorBox);

    document.body.appendChild(wrapper);

    try {
        const visual = new Visual({ element: box, host });
        visual.update({
            viewport: { width, height },
            dataViews: [buildDataView(objects, data)],
            type: 2,
            operationKind: 0
        } as any);

        if ((window as any).location.hash === "#debug") {
            const svg = box.querySelector("svg") as SVGSVGElement;
            const info: any[] = [];
            svg.querySelectorAll("text").forEach((t) => {
                const bb = (t as SVGGraphicsElement).getBBox();
                const r = t.getBoundingClientRect();
                info.push({
                    text: t.textContent,
                    x: Math.round(bb.x * 10) / 10,
                    y: Math.round(bb.y * 10) / 10,
                    w: Math.round(bb.width * 10) / 10,
                    h: Math.round(bb.height * 10) / 10,
                    rx: Math.round(r.left * 10) / 10,
                    rw: Math.round(r.width * 10) / 10
                });
            });
            const pre = document.createElement("pre");
            pre.id = "bbox";
            pre.textContent = `svg=${(svg as any).getAttribute("width")}x${(svg as any).getAttribute("height")} box=${box.clientWidth}x${box.clientHeight}\n` +
                info.map((i) => `${i.text} | local x=${i.x} w=${i.w} | screen left=${i.rx} w=${i.rw}`).join("\n");
            document.body.appendChild(pre);
        }

        const empty = box.querySelector(".pareto-empty") as HTMLElement;
        if (empty && empty.style.display !== "none") {
            errorBox.textContent = `空状态：${empty.textContent}`;
        }
    } catch (error) {
        errorBox.textContent = String((error as any)?.stack || error);
    }
}

const single = window.location.hash === "#single" || window.location.hash === "#debug";

if (single) {
    document.body.style.padding = "0";
    document.body.style.margin = "0";
    renderCase("① 默认设置（含空值 / 负数 / 0 值）", {}, { w: 780, h: 420 });
} else {
    renderCase("① 默认设置（含空值 / 负数 / 0 值）", {});
}

if (!single) renderCase("② 平滑折线 + 70% 垂直标记线 + 双序列数值标签", {
    bar: { transparency: 55, fill: color("#2F80ED"), showValues: true, valueDecimals: "0" },
    line: {
        smooth: true, dashType: "dashed", width: 3, markerSize: 8, fill: color("#C0392B"),
        showValues: true, valueDecimals: "1", valueFontSize: 9
    },
    referenceLine: { percent: 70, fill: color("#1B7F5A"), dashType: "dotted" },
    axisTitle: { showXTitle: true, xTitle: "产品类别", yTitle: "销售额（万元）" }
});

if (!single) renderCase("③ 负数取绝对值 + 空值按 0 + 标签 45°", {
    dataHandling: { negativeHandling: "absolute", blankHandling: "zero" },
    axisFormat: { xLabelRotation: "45" }
}, { w: 520, h: 360 });

const many: Row[] = [];
for (let i = 0; i < 45; i++) {
    many.push({ category: `类别编号 ${i + 1}`, value: Math.round(200 * Math.pow(0.93, i)) });
}

if (!single) renderCase("⑤ 45 个类别（标签自动抽稀）", {}, { w: 780, h: 360 }, many);

if (!single) renderCase("④ 窄尺寸 + 隐藏辅助轴", {
    axisFormat: { showY2Axis: false },
    axisTitle: { showY2Title: false }
}, { w: 360, h: 300 });
