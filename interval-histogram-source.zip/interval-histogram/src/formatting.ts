"use strict";

import powerbi from "powerbi-visuals-api";
import { Settings, LINE_DEFINITIONS, STAT_LABELS, LineStyleName } from "./settings";

/**
 * 新版格式面板（FormattingModel）构建。
 * 与 capabilities.json 中的 objects 一一对应，属性名必须完全一致。
 */

type Slice = powerbi.visuals.FormattingSlice;
type Group = powerbi.visuals.FormattingGroup;
type Card = powerbi.visuals.FormattingCard;

function desc(objectName: string, propertyName: string): any {
    return { objectName: objectName, propertyName: propertyName };
}

function slice(uid: string, displayName: string, control: any): Slice {
    return { uid: uid, displayName: displayName, control: control } as any;
}

function numUpDown(
    objectName: string,
    propertyName: string,
    displayName: string,
    value: number,
    min?: number,
    max?: number,
    unitSymbol?: string
): Slice {
    const options: any = {};
    if (min !== undefined) {
        options.minValue = { type: 0, value: min };
    }
    if (max !== undefined) {
        options.maxValue = { type: 1, value: max };
    }
    if (unitSymbol) {
        options.unitSymbol = unitSymbol;
    }
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "NumUpDown",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value,
            options: options
        }
    });
}

function slider(
    objectName: string,
    propertyName: string,
    displayName: string,
    value: number,
    min: number,
    max: number,
    unitSymbol?: string
): Slice {
    const options: any = {
        minValue: { type: 0, value: min },
        maxValue: { type: 1, value: max }
    };
    if (unitSymbol) {
        options.unitSymbol = unitSymbol;
    }
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "Slider",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value,
            options: options
        }
    });
}

function toggle(objectName: string, propertyName: string, displayName: string, value: boolean): Slice {
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "ToggleSwitch",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value
        }
    });
}

function colorPicker(objectName: string, propertyName: string, displayName: string, value: string): Slice {
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "ColorPicker",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: { value: value }
        }
    });
}

function textInput(objectName: string, propertyName: string, displayName: string, value: string, placeholder: string): Slice {
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "TextInput",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value,
            placeholder: placeholder
        }
    });
}

function dropdown(
    objectName: string,
    propertyName: string,
    displayName: string,
    value: string,
    items: { value: string; displayName: string }[]
): Slice {
    const current = items.filter(i => i.value === value)[0] || items[0];
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "Dropdown",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: { value: current.value, displayName: current.displayName },
            items: items
        }
    });
}

const LINE_STYLE_ITEMS = [
    { value: "solid", displayName: "实线" },
    { value: "dash", displayName: "虚线" },
    { value: "dot", displayName: "点线" },
    { value: "dashDot", displayName: "点划线" }
];

const POSITION_ITEMS = [
    { value: "topRight", displayName: "右上角" },
    { value: "topLeft", displayName: "左上角" },
    { value: "bottomRight", displayName: "右下角" },
    { value: "bottomLeft", displayName: "左下角" }
];

const ANGLE_ITEMS = [
    { value: "0", displayName: "水平 0°" },
    { value: "45", displayName: "倾斜 45°" },
    { value: "90", displayName: "垂直 90°" }
];

function group(
    uid: string,
    displayName: string,
    slices: Slice[],
    topLevelToggleDescriptor?: { objectName: string; propertyName: string; value: boolean },
    collapsible?: boolean
): Group {
    const g: any = {
        uid: uid,
        displayName: displayName,
        slices: slices
    };
    if (topLevelToggleDescriptor) {
        g.topLevelToggle = {
            uid: `${uid}_toggle`,
            suppressDisplayName: true,
            control: {
                type: "ToggleSwitch",
                properties: {
                    descriptor: desc(topLevelToggleDescriptor.objectName, topLevelToggleDescriptor.propertyName),
                    value: topLevelToggleDescriptor.value
                }
            }
        } as any;
    }
    if (collapsible !== undefined) {
        g.collapsible = collapsible;
    }
    return g as Group;
}

export function buildFormattingModel(settings: Settings, themeColor: string): powerbi.visuals.FormattingModel {
    const s = settings;
    const cards: Card[] = [];

    /* ---------------- 柱形与分箱 ---------------- */
    cards.push({
        uid: "card_bins",
        displayName: "分箱与柱形",
        groups: [
            group("group_bins", "数据分箱", [
                slider("bins", "binCount", "区间数量", s.binCount, 2, 200)
            ]),
            group("group_bars", "柱形", [
                colorPicker("bars", "fillColor", "填充颜色", s.barFillSet && s.barFill ? s.barFill : themeColor),
                slider("bars", "transparency", "透明度", s.barTransparency, 0, 100, "%"),
                numUpDown("bars", "gap", "柱间距", s.barGap, 0, 0.8),
                numUpDown("bars", "cornerRadius", "圆角半径", s.barRadius, 0, 20, "px"),
                toggle("bars", "showBorder", "显示描边", s.barBorder),
                colorPicker("bars", "borderColor", "描边颜色", s.barBorderColor)
            ])
        ]
    } as Card);

    /* ---------------- 常量线 ---------------- */
    const lineGroups: Group[] = [];
    for (const def of LINE_DEFINITIONS) {
        const ls = s.lines[def.key];
        lineGroups.push(group(
            `group_${def.objectName}`,
            def.label,
            [
                colorPicker(def.objectName, "lineColor", "颜色", ls.color),
                numUpDown(def.objectName, "lineWidth", "粗细", ls.width, 0.5, 8, "px"),
                dropdown(def.objectName, "lineStyle", "线型", ls.style as string, LINE_STYLE_ITEMS),
                toggle(def.objectName, "showLabel", "显示名称与值", ls.showLabel)
            ],
            { objectName: def.objectName, propertyName: "show", value: ls.show },
            true
        ));
    }
    cards.push({
        uid: "card_lines",
        displayName: "常量参考线",
        groups: lineGroups
    } as Card);

    /* ---------------- KDE ---------------- */
    cards.push({
        uid: "card_kde",
        displayName: "KDE 密度曲线",
        groups: [
            group("group_kde", "密度曲线", [
                colorPicker("kde", "lineColor", "颜色", s.kdeColor),
                numUpDown("kde", "lineWidth", "粗细", s.kdeWidth, 0.5, 8, "px"),
                dropdown("kde", "lineStyle", "线型", s.kdeStyle as string, LINE_STYLE_ITEMS),
                numUpDown("kde", "bandwidth", "带宽倍数", s.kdeBandwidth, 0.1, 4),
                toggle("kde", "showArea", "曲线下方填充", s.kdeShowArea),
                slider("kde", "areaTransparency", "填充透明度", s.kdeAreaTransparency, 0, 100, "%")
            ], { objectName: "kde", propertyName: "show", value: s.kdeShow })
        ]
    } as Card);

    /* ---------------- 坐标轴 ---------------- */
    cards.push({
        uid: "card_axes",
        displayName: "坐标轴与标签",
        groups: [
            group("group_axis_visibility", "坐标轴", [
                toggle("axes", "showXAxis", "显示 X 轴", s.showXAxis),
                toggle("axes", "showYAxis", "显示 Y 轴", s.showYAxis),
                toggle("axes", "showGridlines", "显示横向网格线", s.showGridlines),
                colorPicker("axes", "gridlineColor", "网格线颜色", s.gridlineColor),
                toggle("axes", "yFromZero", "Y 轴从 0 开始", s.yFromZero)
            ]),
            group("group_axis_titles", "轴标题", [
                toggle("axes", "showXTitle", "显示 X 轴标题", s.showXTitle),
                textInput("axes", "xTitle", "X 轴标题", s.xTitle, "区间"),
                toggle("axes", "showYTitle", "显示 Y 轴标题", s.showYTitle),
                textInput("axes", "yTitle", "Y 轴标题", s.yTitle, "计数")
            ]),
            group("group_axis_format", "标签格式", [
                dropdown("axes", "labelAngle", "X 轴刻度角度", String(s.labelAngle), ANGLE_ITEMS),
                numUpDown("axes", "axisFontSize", "刻度字号", s.axisFontSize, 6, 24, "pt"),
                numUpDown("axes", "titleFontSize", "标题字号", s.titleFontSize, 6, 28, "pt"),
                colorPicker("axes", "labelColor", "标签颜色", s.labelColor),
                colorPicker("axes", "axisColor", "轴线颜色", s.axisColor)
            ])
        ]
    } as Card);

    /* ---------------- 统计量图例 ---------------- */
    const statSlices: Slice[] = STAT_LABELS.map(item =>
        toggle("stats", item.key, item.label, s.statsVisible[item.key])
    );

    cards.push({
        uid: "card_stats",
        displayName: "统计量图例",
        groups: [
            group("group_stats_layout", "布局", [
                dropdown("stats", "position", "位置", s.statsPosition, POSITION_ITEMS),
                numUpDown("stats", "columns", "列数", s.statsColumns, 1, 3),
                numUpDown("stats", "fontSize", "字号", s.statsFontSize, 6, 24, "pt"),
                numUpDown("stats", "decimals", "小数位", s.statsDecimals, 0, 6)
            ]),
            group("group_stats_style", "外观", [
                colorPicker("stats", "fontColor", "文字颜色", s.statsFontColor),
                colorPicker("stats", "backgroundColor", "背景颜色", s.statsBackground),
                slider("stats", "transparency", "背景透明度", s.statsTransparency, 0, 100, "%"),
                toggle("stats", "showBorder", "显示边框", s.statsShowBorder),
                colorPicker("stats", "borderColor", "边框颜色", s.statsBorderColor)
            ]),
            group("group_stats_items", "显示哪些统计量", statSlices, undefined)
        ],
        // 卡片级开关：图例总开关
        topLevelToggle: {
            uid: "stats_card_toggle",
            suppressDisplayName: true,
            control: {
                type: "ToggleSwitch",
                properties: {
                    descriptor: desc("stats", "show"),
                    value: s.statsShow
                }
            }
        } as any
    } as Card);

    return { cards: cards };
}
