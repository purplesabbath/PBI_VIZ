"use strict";

import powerbi from "powerbi-visuals-api";
import { SummaryStats } from "./stats";

export type LineStyleName = "solid" | "dash" | "dot" | "dashDot";

export type StatKey =
    "mean" | "median" | "std" | "variance" | "count" | "max" | "min" |
    "cv" | "vsf" | "skewness" | "kurtosis" | "p25" | "p75" | "p90" | "p10";

export type StatsPosition = "topRight" | "topLeft" | "bottomRight" | "bottomLeft";

export interface LineSettings {
    show: boolean;
    color: string;
    width: number;
    style: LineStyleName;
    showLabel: boolean;
}

export interface LineDefinition {
    objectName: string;
    key: string;
    label: string;
    defaultColor: string;
    defaultShow: boolean;
    defaultWidth: number;
    defaultStyle: LineStyleName;
    value: (s: SummaryStats) => number;
}

export const LINE_DEFINITIONS: LineDefinition[] = [
    {
        objectName: "m3Sigma", key: "m3", label: "均值 -3σ", defaultColor: "#8E44AD",
        defaultShow: true, defaultWidth: 1, defaultStyle: "dash",
        value: (s) => s.mean - 3 * s.std
    },
    {
        objectName: "m2Sigma", key: "m2", label: "均值 -2σ", defaultColor: "#16A085",
        defaultShow: false, defaultWidth: 1, defaultStyle: "dash",
        value: (s) => s.mean - 2 * s.std
    },
    {
        objectName: "m1Sigma", key: "m1", label: "均值 -1σ", defaultColor: "#E67E22",
        defaultShow: true, defaultWidth: 1, defaultStyle: "dash",
        value: (s) => s.mean - s.std
    },
    {
        objectName: "sigmaLine", key: "sigma", label: "标准差 σ", defaultColor: "#8C8C8C",
        defaultShow: false, defaultWidth: 1, defaultStyle: "dot",
        value: (s) => s.std
    },
    {
        objectName: "medianLine", key: "median", label: "中位数", defaultColor: "#1F6FB2",
        defaultShow: true, defaultWidth: 1.5, defaultStyle: "solid",
        value: (s) => s.median
    },
    {
        objectName: "meanLine", key: "mean", label: "均值", defaultColor: "#C0392B",
        defaultShow: true, defaultWidth: 1.5, defaultStyle: "solid",
        value: (s) => s.mean
    },
    {
        objectName: "p1Sigma", key: "p1", label: "均值 +1σ", defaultColor: "#E67E22",
        defaultShow: true, defaultWidth: 1, defaultStyle: "solid",
        value: (s) => s.mean + s.std
    },
    {
        objectName: "p2Sigma", key: "p2", label: "均值 +2σ", defaultColor: "#16A085",
        defaultShow: false, defaultWidth: 1, defaultStyle: "solid",
        value: (s) => s.mean + 2 * s.std
    },
    {
        objectName: "p3Sigma", key: "p3", label: "均值 +3σ", defaultColor: "#8E44AD",
        defaultShow: true, defaultWidth: 1, defaultStyle: "solid",
        value: (s) => s.mean + 3 * s.std
    }
];

export const STAT_LABELS: { key: StatKey; label: string }[] = [
    { key: "mean", label: "均值" },
    { key: "median", label: "中位数" },
    { key: "std", label: "标准差" },
    { key: "variance", label: "方差" },
    { key: "count", label: "计数" },
    { key: "max", label: "最大值" },
    { key: "min", label: "最小值" },
    { key: "cv", label: "CV" },
    { key: "vsf", label: "VSF" },
    { key: "skewness", label: "偏度" },
    { key: "kurtosis", label: "峰度" },
    { key: "p25", label: "P25" },
    { key: "p75", label: "P75" },
    { key: "p90", label: "P90" },
    { key: "p10", label: "P10" }
];

export const DEFAULT_STAT_VISIBILITY: { [key in StatKey]: boolean } = {
    mean: true,
    median: true,
    std: true,
    variance: false,
    count: true,
    max: false,
    min: false,
    cv: false,
    vsf: false,
    skewness: false,
    kurtosis: false,
    p25: false,
    p75: false,
    p90: false,
    p10: false
};

function getObject(dataView: powerbi.DataView, objectName: string): any {
    const objects = dataView && dataView.metadata ? dataView.metadata.objects : null;
    if (!objects) {
        return null;
    }
    return objects[objectName] || null;
}

function num(obj: any, prop: string, def: number): number {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null || v === "") {
        return def;
    }
    const parsed = typeof v === "number" ? v : parseFloat(v as any);
    return isFinite(parsed) ? parsed : def;
}

function bool(obj: any, prop: string, def: boolean): boolean {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null) {
        return def;
    }
    if (typeof v === "boolean") {
        return v;
    }
    return String(v).toLowerCase() === "true";
}

function str(obj: any, prop: string, def: string): string {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null) {
        return def;
    }
    return String(v);
}

/** Power BI 的颜色属性可能是 { solid: { color } } 对象，也可能直接是字符串 */
function color(obj: any, prop: string, def: string): string {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null) {
        return def;
    }
    if (typeof v === "string") {
        return v;
    }
    if (v.solid && v.solid.color) {
        return v.solid.color;
    }
    return def;
}

function hasColor(obj: any, prop: string): boolean {
    const v = obj ? obj[prop] : undefined;
    return !!(v && (typeof v === "string" || (v.solid && v.solid.color)));
}

function clamp(v: number, min: number, max: number): number {
    return v < min ? min : (v > max ? max : v);
}

export class Settings {
    // 分箱
    public binCount: number = 30;

    // 柱形
    public barFill: string = "";
    public barFillSet: boolean = false;
    public barTransparency: number = 0;
    public barGap: number = 0.08;
    public barRadius: number = 2;
    public barBorder: boolean = false;
    public barBorderColor: string = "#FFFFFF";

    // 常量线
    public lines: { [key: string]: LineSettings } = {};

    // KDE
    public kdeShow: boolean = true;
    public kdeColor: string = "#2C7BE5";
    public kdeWidth: number = 2;
    public kdeStyle: LineStyleName = "solid";
    public kdeBandwidth: number = 1;
    public kdeShowArea: boolean = false;
    public kdeAreaTransparency: number = 88;

    // 坐标轴
    public showXAxis: boolean = true;
    public showYAxis: boolean = true;
    public showXTitle: boolean = true;
    public xTitle: string = "区间";
    public showYTitle: boolean = true;
    public yTitle: string = "计数";
    public labelAngle: number = 0;
    public axisFontSize: number = 10;
    public titleFontSize: number = 11;
    public axisColor: string = "#B3B0AD";
    public labelColor: string = "#605E5C";
    public showGridlines: boolean = true;
    public gridlineColor: string = "#EDEBE9";
    public yFromZero: boolean = true;

    // 统计量图例
    public statsShow: boolean = true;
    public statsPosition: StatsPosition = "topRight";
    public statsColumns: number = 2;
    public statsFontSize: number = 10;
    public statsFontColor: string = "#323130";
    public statsBackground: string = "#FFFFFF";
    public statsTransparency: number = 15;
    public statsShowBorder: boolean = true;
    public statsBorderColor: string = "#E1DFDD";
    public statsDecimals: number = 2;
    public statsVisible: { [key in StatKey]: boolean } = { ...DEFAULT_STAT_VISIBILITY };

    public static parse(dataView: powerbi.DataView): Settings {
        const s = new Settings();
        if (!dataView) {
            return s;
        }

        const bins = getObject(dataView, "bins");
        s.binCount = Math.round(clamp(num(bins, "binCount", 30), 2, 500));

        const bars = getObject(dataView, "bars");
        s.barFillSet = hasColor(bars, "fillColor");
        s.barFill = color(bars, "fillColor", "");
        s.barTransparency = clamp(num(bars, "transparency", 0), 0, 100);
        s.barGap = clamp(num(bars, "gap", 0.08), 0, 0.85);
        s.barRadius = clamp(num(bars, "cornerRadius", 2), 0, 20);
        s.barBorder = bool(bars, "showBorder", false);
        s.barBorderColor = color(bars, "borderColor", "#FFFFFF");

        const lineMap: { [key: string]: LineSettings } = {};
        for (const def of LINE_DEFINITIONS) {
            const o = getObject(dataView, def.objectName);
            lineMap[def.key] = {
                show: bool(o, "show", def.defaultShow),
                color: color(o, "lineColor", def.defaultColor),
                width: clamp(num(o, "lineWidth", def.defaultWidth), 0.5, 8),
                style: str(o, "lineStyle", def.defaultStyle) as LineStyleName,
                showLabel: bool(o, "showLabel", true)
            };
        }
        s.lines = lineMap;

        const kde = getObject(dataView, "kde");
        s.kdeShow = bool(kde, "show", true);
        s.kdeColor = color(kde, "lineColor", "#2C7BE5");
        s.kdeWidth = clamp(num(kde, "lineWidth", 2), 0.5, 8);
        s.kdeStyle = str(kde, "lineStyle", "solid") as LineStyleName;
        s.kdeBandwidth = clamp(num(kde, "bandwidth", 1), 0.1, 4);
        s.kdeShowArea = bool(kde, "showArea", false);
        s.kdeAreaTransparency = clamp(num(kde, "areaTransparency", 88), 0, 100);

        const axes = getObject(dataView, "axes");
        s.showXAxis = bool(axes, "showXAxis", true);
        s.showYAxis = bool(axes, "showYAxis", true);
        s.showXTitle = bool(axes, "showXTitle", true);
        s.xTitle = str(axes, "xTitle", "区间");
        s.showYTitle = bool(axes, "showYTitle", true);
        s.yTitle = str(axes, "yTitle", "计数");
        s.labelAngle = clamp(num(axes, "labelAngle", 0), 0, 90);
        s.axisFontSize = clamp(num(axes, "axisFontSize", 10), 6, 24);
        s.titleFontSize = clamp(num(axes, "titleFontSize", 11), 6, 28);
        s.axisColor = color(axes, "axisColor", "#B3B0AD");
        s.labelColor = color(axes, "labelColor", "#605E5C");
        s.showGridlines = bool(axes, "showGridlines", true);
        s.gridlineColor = color(axes, "gridlineColor", "#EDEBE9");
        s.yFromZero = bool(axes, "yFromZero", true);

        const st = getObject(dataView, "stats");
        s.statsShow = bool(st, "show", true);
        s.statsPosition = (str(st, "position", "topRight") as StatsPosition);
        if (["topRight", "topLeft", "bottomRight", "bottomLeft"].indexOf(s.statsPosition) < 0) {
            s.statsPosition = "topRight";
        }
        s.statsColumns = Math.round(clamp(num(st, "columns", 2), 1, 3));
        s.statsFontSize = clamp(num(st, "fontSize", 10), 6, 24);
        s.statsFontColor = color(st, "fontColor", "#323130");
        s.statsBackground = color(st, "backgroundColor", "#FFFFFF");
        s.statsTransparency = clamp(num(st, "transparency", 15), 0, 100);
        s.statsShowBorder = bool(st, "showBorder", true);
        s.statsBorderColor = color(st, "borderColor", "#E1DFDD");
        s.statsDecimals = Math.round(clamp(num(st, "decimals", 2), 0, 6));

        const visible: any = { ...DEFAULT_STAT_VISIBILITY };
        for (const item of STAT_LABELS) {
            visible[item.key] = bool(st, item.key, DEFAULT_STAT_VISIBILITY[item.key]);
        }
        s.statsVisible = visible;

        return s;
    }
}
