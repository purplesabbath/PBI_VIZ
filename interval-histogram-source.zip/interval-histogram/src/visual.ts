"use strict";

import powerbi from "powerbi-visuals-api";
import "./../style/visual.less";

import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import ISelectionManager = powerbi.extensibility.ISelectionManager;
import ISelectionId = powerbi.extensibility.ISelectionId;
import ITooltipService = powerbi.extensibility.ITooltipService;
import VisualObjectInstance = powerbi.VisualObjectInstance;
import EnumerateVisualObjectInstancesOptions = powerbi.EnumerateVisualObjectInstancesOptions;
import VisualObjectInstanceEnumeration = powerbi.VisualObjectInstanceEnumeration;

import {
    Settings, LINE_DEFINITIONS, LineDefinition, LineSettings, LineStyleName,
    STAT_LABELS, StatKey, StatsPosition
} from "./settings";
import { buildFormattingModel } from "./formatting";
import {
    computeStats, computeBins, computeKde, silvermanBandwidth, ticks, niceCeil, tickStep,
    SummaryStats, BinDatum, KdePoint
} from "./stats";

const NS = "http://www.w3.org/2000/svg";

interface ViewModel {
    values: number[];
    rowIndices: number[];
    categoryColumn: powerbi.DataViewCategoryColumn;
    valueColumn: powerbi.DataViewValueColumn;
    highlightValues: number[];
    hasHighlight: boolean;
    highlightBins: number[];
    stats: SummaryStats;
    bins: BinDatum[];
    binWidth: number;
    domainMin: number;
    domainMax: number;
    kde: KdePoint[];
    kdeBandwidth: number;
    emptyMessage: string;
}

interface PlotRect {
    x: number;
    y: number;
    width: number;
    height: number;
}

interface LineRenderItem {
    definition: LineDefinition;
    settings: LineSettings;
    value: number;
    x: number;
}

interface StatsPanelLayout {
    rect: PlotRect;
    items: { label: string; value: string }[];
    colWidths: number[];
    cols: number;
    lineHeight: number;
    paddingX: number;
    paddingY: number;
    colGap: number;
    fontSize: number;
}

/* ------------------------------------------------------------------ */
/* 通用小工具                                                          */
/* ------------------------------------------------------------------ */

function el(tag: string, attrs?: { [k: string]: any }, parent?: Element): SVGElement {
    const node = document.createElementNS(NS, tag) as SVGElement;
    if (attrs) {
        for (const key in attrs) {
            const v = attrs[key];
            if (v !== undefined && v !== null && v !== "") {
                node.setAttribute(key, String(v));
            }
        }
    }
    if (parent) {
        parent.appendChild(node);
    }
    return node;
}

function clearNode(node: Element): void {
    while (node.firstChild) {
        node.removeChild(node.firstChild);
    }
}

function clamp(v: number, min: number, max: number): number {
    return v < min ? min : (v > max ? max : v);
}

/** 粗略估算文本宽度：中日韩字符按 1em，其余按 0.56em */
function estimateTextWidth(text: string, fontSize: number): number {
    let w = 0;
    for (let i = 0; i < text.length; i++) {
        const code = text.charCodeAt(i);
        w += (code > 0x2e80 && code < 0xa4d0) ? 1.0 : 0.56;
    }
    return w * fontSize;
}

function formatNumber(v: number, decimals: number): string {
    if (!isFinite(v)) {
        return "—";
    }
    try {
        return new Intl.NumberFormat("en-US", {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(v);
    } catch (e) {
        return v.toFixed(decimals);
    }
}

function formatTickValue(v: number, step: number): string {
    if (!isFinite(v)) {
        return "";
    }
    const decimals = step >= 1 ? 0 : Math.min(6, Math.ceil(-Math.log10(step)));
    return formatNumber(v, decimals);
}

function dashArray(style: LineStyleName, width: number): string {
    switch (style) {
        case "dash":
            return `${Math.max(4, width * 5)} ${Math.max(3, width * 3)}`;
        case "dot":
            return `${Math.max(1, width)} ${Math.max(2.5, width * 2)}`;
        case "dashDot":
            return `${Math.max(5, width * 6)} ${Math.max(2.5, width * 2)} ${Math.max(1, width)} ${Math.max(2.5, width * 2)}`;
        default:
            return "none";
    }
}

function toPowerBiColor(hex: string): any {
    return { solid: { color: hex } };
}

/* ------------------------------------------------------------------ */
/* 数据建模                                                            */
/* ------------------------------------------------------------------ */

function countIntoBins(values: number[], binWidth: number, domainMin: number, binCount: number): number[] {
    const counts: number[] = new Array(binCount);
    for (let i = 0; i < binCount; i++) {
        counts[i] = 0;
    }
    if (!(binWidth > 0)) {
        return counts;
    }
    for (let i = 0; i < values.length; i++) {
        let idx = Math.floor((values[i] - domainMin) / binWidth);
        if (idx < 0) {
            idx = 0;
        }
        if (idx > binCount - 1) {
            idx = binCount - 1;
        }
        counts[idx]++;
    }
    return counts;
}

function buildViewModel(dataView: powerbi.DataView, settings: Settings): ViewModel {
    const empty = (msg: string): ViewModel => ({
        values: [], rowIndices: [], categoryColumn: null, valueColumn: null,
        highlightValues: [], hasHighlight: false, highlightBins: [],
        stats: computeStats([]), bins: [], binWidth: 0, domainMin: 0, domainMax: 1,
        kde: [], kdeBandwidth: 0, emptyMessage: msg
    });

    if (!dataView || !dataView.categorical) {
        return empty("请将「类别」字段（文本或日期）和「值」字段（数值或度量值）拖入字段槽位");
    }

    const categorical = dataView.categorical;
    const values = categorical.values;
    if (!values || !values.length) {
        return empty("请添加「值」字段（数值或度量值）");
    }

    const valueColumn = values[0];
    const categoryColumn = categorical.categories && categorical.categories.length
        ? categorical.categories[0]
        : null;

    const raw = valueColumn.values || [];
    const rawHighlight = (valueColumn as any).highlights || null;

    const nums: number[] = [];
    const rowIndices: number[] = [];
    let hasHighlight = false;

    for (let i = 0; i < raw.length; i++) {
        const v = raw[i] as any;
        if (typeof v !== "number" || !isFinite(v)) {
            continue;
        }
        nums.push(v);
        rowIndices.push(i);
        if (rawHighlight && rawHighlight.length > i && rawHighlight[i] !== null && rawHighlight[i] !== undefined) {
            hasHighlight = true;
        }
    }

    if (!nums.length) {
        return empty("当前筛选条件下没有可用的数值");
    }

    // 只放了一个度量值（没有类别）时，Power BI 只会给出一行聚合值，直方图没有意义
    if (!categoryColumn && nums.length < 3) {
        return empty("请把文本或日期字段放入「类别」，让每一行作为一个样本参与分布统计");
    }

    const stats = computeStats(nums);
    const binResult = computeBins(nums, settings.binCount);

    // 高亮（交叉筛选）样本：按同一分箱边界计数
    let highlightBins: number[] = [];
    const highlightValues: number[] = [];
    if (hasHighlight && rawHighlight) {
        for (let i = 0; i < rawHighlight.length; i++) {
            const v = rawHighlight[i] as any;
            if (typeof v === "number" && isFinite(v)) {
                highlightValues.push(v);
            }
        }
        highlightBins = countIntoBins(highlightValues, binResult.binWidth, binResult.domainMin, binResult.bins.length);
    }

    // KDE
    let kde: KdePoint[] = [];
    let kdeBandwidth = 0;
    if (stats.count > 2 && stats.std > 0) {
        const base = silvermanBandwidth(nums, stats);
        kdeBandwidth = base * settings.kdeBandwidth;
        if (kdeBandwidth > 0) {
            const density = computeKde(nums, kdeBandwidth, binResult.domainMin, binResult.domainMax, 220);
            const scale = stats.count * binResult.binWidth;
            kde = density.map(p => ({ x: p.x, y: p.y * scale }));
        }
    }

    return {
        values: nums,
        rowIndices: rowIndices,
        categoryColumn: categoryColumn as any,
        valueColumn: valueColumn,
        highlightValues: highlightValues,
        hasHighlight: hasHighlight && highlightValues.length > 0,
        highlightBins: highlightBins,
        stats: stats,
        bins: binResult.bins,
        binWidth: binResult.binWidth,
        domainMin: binResult.domainMin,
        domainMax: binResult.domainMax,
        kde: kde,
        kdeBandwidth: kdeBandwidth,
        emptyMessage: ""
    };
}

/* ------------------------------------------------------------------ */
/* 视觉对象                                                            */
/* ------------------------------------------------------------------ */

export class Visual implements IVisual {
    private host: IVisualHost;
    private container: HTMLDivElement;
    private svg: SVGSVGElement;
    private tooltipService: ITooltipService;
    private selectionManager: ISelectionManager;

    private settings: Settings = new Settings();
    private model: ViewModel = null;
    private viewport: powerbi.IViewport = { width: 0, height: 0 };
    private plot: PlotRect = { x: 0, y: 0, width: 0, height: 0 };
    private barNodes: SVGRectElement[] = [];
    private selectedBins: number[] = [];
    private hoverBin: number = -1;
    private themeColor: string = "#2C7BE5";

    private readonly onClick = (e: MouseEvent): void => this.handleClick(e);
    private readonly onMove = (e: MouseEvent): void => this.handleMouseMove(e);
    private readonly onLeave = (): void => this.handleMouseLeave();

    constructor(options: VisualConstructorOptions) {
        this.host = options.host;
        this.tooltipService = options.host.tooltipService;
        this.selectionManager = options.host.createSelectionManager();

        this.container = document.createElement("div");
        this.container.className = "interval-histogram";
        options.element.appendChild(this.container);

        this.svg = document.createElementNS(NS, "svg") as SVGSVGElement;
        this.svg.setAttribute("class", "ih-svg");
        this.container.appendChild(this.svg);

        try {
            this.themeColor = options.host.colorPalette.getColor("intervalHistogram").value;
        } catch (e) {
            this.themeColor = "#2C7BE5";
        }

        this.svg.addEventListener("click", this.onClick);
        this.svg.addEventListener("mousemove", this.onMove);
        this.svg.addEventListener("mouseleave", this.onLeave);
    }

    public destroy(): void {
        this.svg.removeEventListener("click", this.onClick);
        this.svg.removeEventListener("mousemove", this.onMove);
        this.svg.removeEventListener("mouseleave", this.onLeave);
    }

    /* --------------------------- 更新 --------------------------- */

    public update(options: VisualUpdateOptions): void {
        const dataView = options.dataViews && options.dataViews[0];
        this.settings = Settings.parse(dataView);
        this.viewport = options.viewport || { width: 0, height: 0 };

        const model = buildViewModel(dataView, this.settings);

        // 选择状态在数据变化后可能失效，做一次收敛
        if (!this.selectionManager.hasSelection()) {
            this.selectedBins = [];
        } else if (this.selectedBins.length) {
            this.selectedBins = this.selectedBins.filter(i => i < model.bins.length);
        }

        this.model = model;
        this.hoverBin = -1;
        this.render();
    }

    /* --------------------------- 渲染 --------------------------- */

    private render(): void {
        const width = Math.max(0, this.viewport.width);
        const height = Math.max(0, this.viewport.height);

        clearNode(this.svg);
        this.barNodes = [];
        this.svg.setAttribute("width", String(width));
        this.svg.setAttribute("height", String(height));
        this.svg.setAttribute("viewBox", `0 0 ${width} ${height}`);

        const model = this.model;
        if (!model || model.emptyMessage || !model.bins.length) {
            this.renderEmpty(width, height, model ? model.emptyMessage : "");
            return;
        }

        const s = this.settings;

        /* ---------- 计算纵轴范围 ---------- */
        let maxCount = 0;
        for (const b of model.bins) {
            if (b.count > maxCount) {
                maxCount = b.count;
            }
        }
        let kdePeak = 0;
        if (s.kdeShow && model.kde.length) {
            for (const p of model.kde) {
                if (p.y > kdePeak) {
                    kdePeak = p.y;
                }
            }
        }
        const dataPeak = Math.max(maxCount, kdePeak, 1);
        const yTicksCount = 5;
        const yMax = niceCeil(dataPeak, yTicksCount);

        let yMin = 0;
        if (!s.yFromZero) {
            let minCount = Infinity;
            for (const b of model.bins) {
                if (b.count < minCount) {
                    minCount = b.count;
                }
            }
            if (!isFinite(minCount)) {
                minCount = 0;
            }
            const stepGuess = tickStep(0, yMax, yTicksCount);
            yMin = Math.max(0, Math.floor(minCount / stepGuess) * stepGuess - stepGuess);
            if (yMin > yMax * 0.8) {
                yMin = 0;
            }
        }

        const yTickValues = ticks(yMin, yMax, yTicksCount);
        if (yTickValues.length < 2) {
            yTickValues.push(yMax);
        }
        const yStep = tickStep(yMin, yMax, yTicksCount);
        const yLabels = yTickValues.map(v => formatTickValue(v, yStep));

        /* ---------- 边距 ---------- */
        let yLabelWidth = 0;
        for (const label of yLabels) {
            const w = estimateTextWidth(label, s.axisFontSize);
            if (w > yLabelWidth) {
                yLabelWidth = w;
            }
        }

        const padTop = 12;
        const padRight = 14;
        const left = (s.showYAxis ? yLabelWidth + 12 : 6)
            + (s.showYTitle && s.yTitle ? s.titleFontSize + 8 : 0);
        const xLabelHeight = s.labelAngle === 0
            ? s.axisFontSize * 1.45
            : (s.labelAngle === 45 ? s.axisFontSize * 2.9 : s.axisFontSize * 3.4);
        const bottom = 4
            + (s.showXAxis ? xLabelHeight + 4 : 0)
            + (s.showXTitle && s.xTitle ? s.titleFontSize + 10 : 0);

        const plotW = width - left - padRight;
        const plotH = height - padTop - bottom;

        if (plotW < 30 || plotH < 30) {
            this.renderEmpty(width, height, "空间不足，请扩大视觉对象尺寸");
            return;
        }

        const plot: PlotRect = { x: left, y: padTop, width: plotW, height: plotH };
        this.plot = plot;

        const domainSpan = model.domainMax - model.domainMin || 1;
        const ySpan = (yMax - yMin) || 1;
        const sx = (v: number): number => plot.x + ((v - model.domainMin) / domainSpan) * plotW;
        const sy = (c: number): number => plot.y + plotH - ((c - yMin) / ySpan) * plotH;
        const baseY = sy(Math.max(yMin, 0));

        const root = el("g", { class: "ih-root" }, this.svg);

        /* ---------- 网格线 ---------- */
        if (s.showGridlines) {
            const grid = el("g", { class: "ih-grid" }, root);
            for (const v of yTickValues) {
                el("line", {
                    x1: plot.x, x2: plot.x + plotW,
                    y1: sy(v), y2: sy(v),
                    stroke: s.gridlineColor, "stroke-width": 1,
                    "shape-rendering": "crispEdges"
                }, grid);
            }
        }

        /* ---------- 柱形 ---------- */
        const barColor = s.barFillSet && s.barFill ? s.barFill : this.themeColor;
        const opacity = 1 - clamp(s.barTransparency, 0, 100) / 100;
        const binPixelWidth = plotW / model.bins.length;
        const gapPx = binPixelWidth * clamp(s.barGap, 0, 0.85);
        const hasSelection = this.selectionManager.hasSelection() && this.selectedBins.length > 0;
        const highlightActive = model.hasHighlight;

        const barsGroup = el("g", { class: "ih-bars" }, root);
        const overlayGroup = el("g", { class: "ih-bars-highlight" }, root);

        for (let i = 0; i < model.bins.length; i++) {
            const bin = model.bins[i];
            const x = sx(bin.x0) + gapPx / 2;
            const w = Math.max(0.6, sx(bin.x1) - sx(bin.x0) - gapPx);
            const y = sy(bin.count);
            const h = Math.max(0, baseY - y);

            const dimmed = hasSelection && this.selectedBins.indexOf(i) < 0;
            let barOpacity = opacity;
            if (highlightActive) {
                barOpacity = opacity * 0.22;
            } else if (dimmed) {
                barOpacity = opacity * 0.25;
            }

            const rect = el("rect", {
                x: x,
                y: y,
                width: w,
                height: h,
                rx: Math.min(s.barRadius, w / 2, h / 2),
                fill: barColor,
                "fill-opacity": barOpacity,
                stroke: s.barBorder ? s.barBorderColor : "none",
                "stroke-width": s.barBorder ? 1 : 0
            }, barsGroup) as SVGRectElement;

            this.barNodes.push(rect);

            if (highlightActive) {
                const hCount = model.highlightBins[i] || 0;
                if (hCount > 0) {
                    const hy = sy(hCount);
                    el("rect", {
                        x: x,
                        y: hy,
                        width: w,
                        height: Math.max(0, baseY - hy),
                        rx: Math.min(s.barRadius, w / 2, Math.max(0, baseY - hy) / 2),
                        fill: barColor,
                        "fill-opacity": opacity,
                        stroke: s.barBorder ? s.barBorderColor : "none",
                        "stroke-width": s.barBorder ? 1 : 0,
                        "pointer-events": "none"
                    }, overlayGroup);
                }
            }
        }

        /* ---------- KDE 曲线 ---------- */
        if (s.kdeShow && model.kde.length > 1) {
            const g = el("g", { class: "ih-kde", "pointer-events": "none" }, root);
            let d = "";
            for (let i = 0; i < model.kde.length; i++) {
                const p = model.kde[i];
                d += (i === 0 ? "M" : "L") + sx(p.x).toFixed(2) + " " + sy(Math.min(p.y, yMax)).toFixed(2);
            }
            if (s.kdeShowArea) {
                const areaD = d
                    + `L${sx(model.kde[model.kde.length - 1].x).toFixed(2)} ${baseY.toFixed(2)}`
                    + `L${sx(model.kde[0].x).toFixed(2)} ${baseY.toFixed(2)}Z`;
                el("path", {
                    d: areaD,
                    fill: s.kdeColor,
                    "fill-opacity": 1 - clamp(s.kdeAreaTransparency, 0, 100) / 100,
                    stroke: "none"
                }, g);
            }
            el("path", {
                d: d,
                fill: "none",
                stroke: s.kdeColor,
                "stroke-width": s.kdeWidth,
                "stroke-dasharray": dashArray(s.kdeStyle, s.kdeWidth),
                "stroke-linejoin": "round",
                "stroke-linecap": "round"
            }, g);
        }

        /* ---------- 坐标轴 ---------- */
        this.renderAxes(root, plot, model, sx, yTickValues, yLabels, yMax);

        /* ---------- 统计量图例（先算好位置，供常量线标签避让） ---------- */
        const statsLayout = s.statsShow ? this.layoutStatsPanel(plot, model) : null;

        /* ---------- 常量线 ---------- */
        this.renderConstantLines(root, plot, model, sx, statsLayout ? statsLayout.rect : null);

        /* ---------- 统计量图例 ---------- */
        if (statsLayout) {
            this.drawStatsPanel(root, statsLayout, plot);
        }
    }

    private renderEmpty(width: number, height: number, message: string): void {
        if (!message) {
            return;
        }
        const g = el("g", { class: "ih-empty" }, this.svg);
        const lines = this.wrapText(message, Math.max(80, width - 40), 12);
        const lineHeight = 18;
        const totalHeight = lines.length * lineHeight;
        const startY = Math.max(20, height / 2 - totalHeight / 2 + 12);
        for (let i = 0; i < lines.length; i++) {
            el("text", {
                x: width / 2,
                y: startY + i * lineHeight,
                "text-anchor": "middle",
                fill: "#8A8886",
                "font-size": 12,
                "font-family": "'Segoe UI', 'Microsoft YaHei', sans-serif"
            }, g).textContent = lines[i];
        }
    }

    private wrapText(text: string, maxWidth: number, fontSize: number): string[] {
        const result: string[] = [];
        let current = "";
        for (const ch of text) {
            const next = current + ch;
            if (estimateTextWidth(next, fontSize) > maxWidth && current.length) {
                result.push(current);
                current = ch;
            } else {
                current = next;
            }
        }
        if (current) {
            result.push(current);
        }
        return result.length ? result : [text];
    }

    private renderAxes(
        root: SVGElement,
        plot: PlotRect,
        model: ViewModel,
        sx: (v: number) => number,
        yTickValues: number[],
        yLabels: string[],
        yMax: number
    ): void {
        const s = this.settings;
        const g = el("g", { class: "ih-axis" }, root);
        const font = `'Segoe UI', 'Microsoft YaHei', sans-serif`;

        // X 轴刻度
        if (s.showXAxis) {
            const tickCount = clamp(Math.round(plot.width / 78), 2, 10);
            const xTicks = ticks(model.domainMin, model.domainMax, tickCount);
            const xStep = tickStep(model.domainMin, model.domainMax, tickCount);

            el("line", {
                x1: plot.x, x2: plot.x + plot.width,
                y1: plot.y + plot.height, y2: plot.y + plot.height,
                stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
            }, g);

            for (const t of xTicks) {
                if (t < model.domainMin - 1e-9 || t > model.domainMax + 1e-9) {
                    continue;
                }
                const x = sx(t);
                el("line", {
                    x1: x, x2: x,
                    y1: plot.y + plot.height, y2: plot.y + plot.height + 4,
                    stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
                }, g);

                const label = formatTickValue(t, xStep);
                const textAttrs: { [k: string]: any } = {
                    x: x,
                    y: plot.y + plot.height + (s.labelAngle === 0 ? 14 : 10),
                    fill: s.labelColor,
                    "font-size": s.axisFontSize,
                    "font-family": font
                };
                if (s.labelAngle === 0) {
                    textAttrs["text-anchor"] = "middle";
                } else {
                    textAttrs["text-anchor"] = "end";
                    textAttrs["transform"] = `rotate(${-s.labelAngle}, ${x}, ${plot.y + plot.height + 10})`;
                }
                el("text", textAttrs, g).textContent = label;
            }

            if (s.showXTitle && s.xTitle) {
                const titleY = s.showXAxis
                    ? plot.y + plot.height + (s.labelAngle === 0 ? 14 : 10) + xAxisTitleOffset(s) + s.titleFontSize
                    : plot.y + plot.height + s.titleFontSize + 6;

                el("text", {
                    x: plot.x + plot.width / 2,
                    y: titleY,
                    "text-anchor": "middle",
                    fill: s.labelColor,
                    "font-size": s.titleFontSize,
                    "font-family": font
                }, g).textContent = s.xTitle;
            }
        }

        // Y 轴刻度
        if (s.showYAxis) {
            el("line", {
                x1: plot.x, x2: plot.x,
                y1: plot.y, y2: plot.y + plot.height,
                stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
            }, g);

            const yMinValue = yTickValues[0];
            const ySpan = (yMax - yMinValue) || 1;

            for (let i = 0; i < yTickValues.length; i++) {
                const v = yTickValues[i];
                const yy = plot.y + plot.height - ((v - yMinValue) / ySpan) * plot.height;

                el("line", {
                    x1: plot.x - 4, x2: plot.x,
                    y1: yy, y2: yy,
                    stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
                }, g);

                el("text", {
                    x: plot.x - 7,
                    y: yy + s.axisFontSize * 0.35,
                    "text-anchor": "end",
                    fill: s.labelColor,
                    "font-size": s.axisFontSize,
                    "font-family": font
                }, g).textContent = yLabels[i];
            }

            if (s.showYTitle && s.yTitle) {
                const titleX = 8 + s.titleFontSize * 0.5;
                el("text", {
                    x: 0,
                    y: 0,
                    transform: `translate(${titleX}, ${plot.y + plot.height / 2}) rotate(-90)`,
                    "text-anchor": "middle",
                    fill: s.labelColor,
                    "font-size": s.titleFontSize,
                    "font-family": font
                }, g).textContent = s.yTitle;
            }
        }
    }

    private renderConstantLines(
        root: SVGElement,
        plot: PlotRect,
        model: ViewModel,
        sx: (v: number) => number,
        blocked: PlotRect | null
    ): void {
        const s = this.settings;
        const stats = model.stats;
        const items: LineRenderItem[] = [];

        for (const def of LINE_DEFINITIONS) {
            const ls = s.lines[def.key];
            if (!ls || !ls.show) {
                continue;
            }
            const value = def.value(stats);
            if (!isFinite(value)) {
                continue;
            }
            if (value < model.domainMin || value > model.domainMax) {
                continue;
            }
            items.push({ definition: def, settings: ls, value: value, x: sx(value) });
        }

        if (!items.length) {
            return;
        }

        const g = el("g", { class: "ih-lines", "pointer-events": "none" }, root);

        // 先画线
        for (const item of items) {
            el("line", {
                x1: item.x, x2: item.x,
                y1: plot.y, y2: plot.y + plot.height,
                stroke: item.settings.color,
                "stroke-width": item.settings.width,
                "stroke-dasharray": dashArray(item.settings.style, item.settings.width),
                "stroke-linecap": "butt"
            }, g);
        }

        // 再画标签（自动分道避让）
        const labels = items.filter(i => i.settings.showLabel);
        if (!labels.length) {
            return;
        }

        const ordered = labels.slice().sort((a, b) => a.x - b.x);
        const font = `'Segoe UI', 'Microsoft YaHei', sans-serif`;
        const fontSize = Math.max(9, Math.min(12, s.axisFontSize));
        const laneHeight = fontSize + 6;
        const laneRight: number[] = [];
        const laneLimit = Math.max(1, Math.floor((plot.height * 0.55) / laneHeight));

        ordered.forEach(item => {
            const text = `${item.definition.label} ${formatNumber(item.value, this.autoDecimals(model, 2))}`;
            const w = estimateTextWidth(text, fontSize) + 10;
            const h = fontSize + 5;
            let left = item.x - w / 2;
            left = clamp(left, plot.x + 1, plot.x + plot.width - w - 1);

            let lane = 0;
            while (lane < laneLimit) {
                const candidateTop = plot.y + 3 + lane * laneHeight;
                const hitsPrevious = laneRight[lane] !== undefined && left < laneRight[lane] + 4;
                const hitsBlocked = blocked
                    ? this.rectsIntersect(left, candidateTop, w, h, blocked)
                    : false;
                if (!hitsPrevious && !hitsBlocked) {
                    break;
                }
                lane++;
            }
            if (lane >= laneLimit) {
                return;
            }
            laneRight[lane] = left + w;

            const top = plot.y + 3 + lane * laneHeight;

            el("rect", {
                x: left, y: top, width: w, height: h,
                rx: 2, ry: 2,
                fill: "#FFFFFF", "fill-opacity": 0.82,
                stroke: item.settings.color, "stroke-opacity": 0.35, "stroke-width": 0.8
            }, g);

            el("text", {
                x: left + w / 2,
                y: top + h / 2 + fontSize * 0.36,
                "text-anchor": "middle",
                fill: item.settings.color,
                "font-size": fontSize,
                "font-weight": 600,
                "font-family": font
            }, g).textContent = text;
        });
    }

    /** 根据数据量级给出合理的小数位 */
    private autoDecimals(model: ViewModel, maxDecimals: number): number {
        const span = Math.abs(model.domainMax - model.domainMin);
        if (!isFinite(span) || span === 0) {
            return Math.min(2, maxDecimals);
        }
        if (span >= 1000) {
            return 0;
        }
        if (span >= 100) {
            return 1;
        }
        return Math.min(maxDecimals, 2);
    }

    private rectsIntersect(
        ax: number, ay: number, aw: number, ah: number,
        b: PlotRect
    ): boolean {
        return !(ax + aw < b.x || ax > b.x + b.width || ay + ah < b.y || ay > b.y + b.height);
    }

    /** 计算统计量图例的尺寸与位置（不绘制） */
    private layoutStatsPanel(plot: PlotRect, model: ViewModel): StatsPanelLayout | null {
        const s = this.settings;
        const stats = model.stats;
        const decimals = s.statsDecimals;

        const items: { label: string; value: string }[] = [];
        for (const def of STAT_LABELS) {
            if (!s.statsVisible[def.key]) {
                continue;
            }
            const raw = (stats as any)[def.key];
            let text: string;
            if (def.key === "count") {
                text = String(Math.round(raw));
            } else if (!isFinite(raw)) {
                text = "—";
            } else {
                text = formatNumber(raw, decimals);
            }
            items.push({ label: def.label, value: text });
        }
        if (!items.length) {
            return null;
        }

        const fontSize = s.statsFontSize;
        const cols = Math.max(1, Math.min(s.statsColumns, items.length, 3));
        const rows = Math.ceil(items.length / cols);
        const lineHeight = fontSize * 1.6;
        const paddingX = 9;
        const paddingY = 7;
        const colGap = 14;

        const colWidths: number[] = [];
        for (let c = 0; c < cols; c++) {
            colWidths.push(0);
        }
        items.forEach((item, i) => {
            const c = i % cols;
            const w = estimateTextWidth(item.label, fontSize) + 8 + estimateTextWidth(item.value, fontSize);
            if (w > colWidths[c]) {
                colWidths[c] = w;
            }
        });

        let contentWidth = 0;
        for (let c = 0; c < cols; c++) {
            contentWidth += colWidths[c] + (c > 0 ? colGap : 0);
        }

        const panelW = contentWidth + paddingX * 2;
        const panelH = rows * lineHeight + paddingY * 2;

        const inset = 12;
        const position: StatsPosition = s.statsPosition;
        const isRight = position === "topRight" || position === "bottomRight";
        const isBottom = position === "bottomLeft" || position === "bottomRight";

        let panelX = isRight ? plot.x + plot.width - panelW - inset : plot.x + inset;
        let panelY = isBottom ? plot.y + plot.height - panelH - inset : plot.y + inset;

        panelX = Math.max(plot.x + 2, Math.min(panelX, plot.x + plot.width - panelW - 2));
        panelY = Math.max(plot.y + 2, Math.min(panelY, plot.y + plot.height - panelH - 2));

        return {
            rect: { x: panelX, y: panelY, width: panelW, height: panelH },
            items: items,
            colWidths: colWidths,
            cols: cols,
            lineHeight: lineHeight,
            paddingX: paddingX,
            paddingY: paddingY,
            colGap: colGap,
            fontSize: fontSize
        };
    }

    private drawStatsPanel(root: SVGElement, layout: StatsPanelLayout, plot: PlotRect): void {
        const s = this.settings;
        const rect = layout.rect;
        const g = el("g", { class: "ih-stats", "pointer-events": "none" }, root);

        el("rect", {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
            rx: 4,
            ry: 4,
            fill: s.statsBackground,
            "fill-opacity": 1 - clamp(s.statsTransparency, 0, 100) / 100,
            stroke: s.statsShowBorder ? s.statsBorderColor : "none",
            "stroke-width": s.statsShowBorder ? 1 : 0
        }, g);

        const font = `'Segoe UI', 'Microsoft YaHei', sans-serif`;

        layout.items.forEach((item, i) => {
            const c = i % layout.cols;
            const r = Math.floor(i / layout.cols);
            let colX = rect.x + layout.paddingX;
            for (let k = 0; k < c; k++) {
                colX += layout.colWidths[k] + layout.colGap;
            }
            const y = rect.y + layout.paddingY + r * layout.lineHeight + layout.fontSize * 1.02;

            el("text", {
                x: colX,
                y: y,
                fill: s.statsFontColor,
                "fill-opacity": 0.72,
                "font-size": layout.fontSize,
                "font-family": font
            }, g).textContent = item.label;

            el("text", {
                x: colX + layout.colWidths[c],
                y: y,
                "text-anchor": "end",
                fill: s.statsFontColor,
                "font-size": layout.fontSize,
                "font-weight": 600,
                "font-family": font
            }, g).textContent = item.value;
        });
    }

    /* --------------------------- 交互 --------------------------- */

    private eventPoint(e: MouseEvent): { x: number; y: number } {
        const rect = this.svg.getBoundingClientRect();
        return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }

    private binIndexAt(x: number): number {
        const model = this.model;
        if (!model || !model.bins.length || !(this.plot.width > 0)) {
            return -1;
        }
        if (x < this.plot.x || x > this.plot.x + this.plot.width) {
            return -1;
        }
        const ratio = (x - this.plot.x) / this.plot.width;
        const idx = Math.floor(ratio * model.bins.length);
        return clamp(idx, 0, model.bins.length - 1);
    }

    private buildSelectionIds(binIndex: number): ISelectionId[] {
        const model = this.model;
        if (!model || !model.categoryColumn) {
            return [];
        }
        const ids: ISelectionId[] = [];
        const bin = model.bins[binIndex];
        for (const rowIndex of bin.indices) {
            const row = model.rowIndices[rowIndex];
            ids.push(this.host.createSelectionIdBuilder()
                .withCategory(model.categoryColumn, row)
                .createSelectionId());
        }
        return ids;
    }

    private handleClick(e: MouseEvent): void {
        const model = this.model;
        if (!model || !model.bins.length) {
            return;
        }
        const point = this.eventPoint(e);
        const idx = this.binIndexAt(point.x);

        if (idx < 0) {
            this.selectedBins = [];
            this.selectionManager.clear();
            this.render();
            return;
        }

        const ids = this.buildSelectionIds(idx);
        if (!ids.length) {
            return;
        }

        const multi = e.ctrlKey || e.metaKey || e.shiftKey;
        let next: number[];
        if (multi) {
            next = this.selectedBins.indexOf(idx) >= 0
                ? this.selectedBins.filter(i => i !== idx)
                : this.selectedBins.concat([idx]);
        } else {
            next = this.selectedBins.length === 1 && this.selectedBins[0] === idx ? [] : [idx];
        }

        const allIds: ISelectionId[] = [];
        for (const i of next) {
            allIds.push(...this.buildSelectionIds(i));
        }

        this.selectedBins = next;

        if (!allIds.length) {
            this.selectionManager.clear();
            this.render();
            return;
        }

        this.selectionManager.select(allIds, multi).then(() => {
            this.render();
        }, () => {
            this.render();
        });
    }

    private handleMouseMove(e: MouseEvent): void {
        const model = this.model;
        if (!model || !model.bins.length) {
            return;
        }
        const point = this.eventPoint(e);
        const idx = this.binIndexAt(point.x);

        if (idx < 0) {
            this.hideTooltip();
            this.setHoverBin(-1);
            return;
        }

        this.setHoverBin(idx);

        const bin = model.bins[idx];
        const total = model.stats.count;
        const share = total ? (bin.count / total) * 100 : 0;
        const dec = this.autoDecimals(model, 2);

        const dataItems: powerbi.extensibility.VisualTooltipDataItem[] = [
            { displayName: "区间", value: `${formatNumber(bin.x0, dec)} ~ ${formatNumber(bin.x1, dec)}` },
            { displayName: "计数", value: String(bin.count) },
            { displayName: "占比", value: `${share.toFixed(1)}%` }
        ];

        this.tooltipService.show({
            coordinates: [point.x, point.y],
            isTouchEvent: false,
            dataItems: dataItems,
            identities: this.buildSelectionIds(idx)
        });
    }

    private setHoverBin(idx: number): void {
        if (this.hoverBin === idx) {
            return;
        }
        if (this.hoverBin >= 0 && this.barNodes[this.hoverBin]) {
            this.barNodes[this.hoverBin].setAttribute("stroke", this.settings.barBorder ? this.settings.barBorderColor : "none");
            this.barNodes[this.hoverBin].setAttribute("stroke-width", this.settings.barBorder ? "1" : "0");
        }
        this.hoverBin = idx;
        if (idx >= 0 && this.barNodes[idx]) {
            this.barNodes[idx].setAttribute("stroke", "#605E5C");
            this.barNodes[idx].setAttribute("stroke-width", "1");
        }
    }

    private handleMouseLeave(): void {
        this.hideTooltip();
        this.setHoverBin(-1);
    }

    private hideTooltip(): void {
        try {
            this.tooltipService.hide({ immediately: true, isTouchEvent: false });
        } catch (e) {
            // ignore
        }
    }

    /* --------------------------- 属性面板 --------------------------- */

    /** 新版格式面板 */
    public getFormattingModel(): powerbi.visuals.FormattingModel {
        return buildFormattingModel(this.settings, this.themeColor);
    }

    /** 旧版格式面板（兼容较老的 Power BI Desktop） */
    public enumerateObjectInstances(options: EnumerateVisualObjectInstancesOptions): VisualObjectInstanceEnumeration {
        const s = this.settings;
        const instances: VisualObjectInstance[] = [];

        const push = (objectName: string, displayName: string, properties: any): void => {
            instances.push({ objectName: objectName, displayName: displayName, selector: null, properties: properties });
        };

        switch (options.objectName) {
            case "bins":
                push("bins", "数据分箱", {
                    binCount: s.binCount
                });
                break;

            case "bars":
                push("bars", "柱形", {
                    fillColor: toPowerBiColor(s.barFillSet ? s.barFill : this.themeColor),
                    transparency: s.barTransparency,
                    gap: s.barGap,
                    cornerRadius: s.barRadius,
                    showBorder: s.barBorder,
                    borderColor: toPowerBiColor(s.barBorderColor)
                });
                break;

            case "kde":
                push("kde", "KDE 密度曲线", {
                    show: s.kdeShow,
                    lineColor: toPowerBiColor(s.kdeColor),
                    lineWidth: s.kdeWidth,
                    lineStyle: s.kdeStyle,
                    bandwidth: s.kdeBandwidth,
                    showArea: s.kdeShowArea,
                    areaTransparency: s.kdeAreaTransparency
                });
                break;

            case "axes":
                push("axes", "坐标轴与标签", {
                    showXAxis: s.showXAxis,
                    showYAxis: s.showYAxis,
                    showXTitle: s.showXTitle,
                    xTitle: s.xTitle,
                    showYTitle: s.showYTitle,
                    yTitle: s.yTitle,
                    labelAngle: String(s.labelAngle),
                    axisFontSize: s.axisFontSize,
                    titleFontSize: s.titleFontSize,
                    axisColor: toPowerBiColor(s.axisColor),
                    labelColor: toPowerBiColor(s.labelColor),
                    showGridlines: s.showGridlines,
                    gridlineColor: toPowerBiColor(s.gridlineColor),
                    yFromZero: s.yFromZero
                });
                break;

            case "stats":
                push("stats", "统计量图例", {
                    show: s.statsShow,
                    position: s.statsPosition,
                    columns: s.statsColumns,
                    fontSize: s.statsFontSize,
                    fontColor: toPowerBiColor(s.statsFontColor),
                    backgroundColor: toPowerBiColor(s.statsBackground),
                    transparency: s.statsTransparency,
                    showBorder: s.statsShowBorder,
                    borderColor: toPowerBiColor(s.statsBorderColor),
                    decimals: s.statsDecimals,
                    mean: s.statsVisible.mean,
                    median: s.statsVisible.median,
                    std: s.statsVisible.std,
                    variance: s.statsVisible.variance,
                    count: s.statsVisible.count,
                    max: s.statsVisible.max,
                    min: s.statsVisible.min,
                    cv: s.statsVisible.cv,
                    vsf: s.statsVisible.vsf,
                    skewness: s.statsVisible.skewness,
                    kurtosis: s.statsVisible.kurtosis,
                    p25: s.statsVisible.p25,
                    p75: s.statsVisible.p75,
                    p90: s.statsVisible.p90,
                    p10: s.statsVisible.p10
                });
                break;

            default: {
                for (const def of LINE_DEFINITIONS) {
                    if (def.objectName !== options.objectName) {
                        continue;
                    }
                    const ls = s.lines[def.key];
                    push(def.objectName, "常量线 · " + def.label, {
                        show: ls.show,
                        lineColor: toPowerBiColor(ls.color),
                        lineWidth: ls.width,
                        lineStyle: ls.style,
                        showLabel: ls.showLabel
                    });
                }
                break;
            }
        }

        return instances;
    }
}

function xAxisTitleOffset(s: Settings): number {
    if (s.labelAngle === 0) {
        return 4;
    }
    return s.axisFontSize * 1.1;
}
