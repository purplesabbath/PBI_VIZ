"use strict";

/**
 * 统计计算工具：描述性统计量、等宽分箱、高斯核密度估计。
 * 全部为纯函数，方便单独测试。
 */

export interface SummaryStats {
    count: number;
    sum: number;
    mean: number;
    median: number;
    /** 样本方差（除以 n-1） */
    variance: number;
    /** 样本标准差（除以 n-1） */
    std: number;
    min: number;
    max: number;
    range: number;
    p10: number;
    p25: number;
    p75: number;
    p90: number;
    iqr: number;
    /** 变异系数 = 标准差 / 均值 */
    cv: number;
    /** VSF = 标准差 / 中位数（稳健变异系数） */
    vsf: number;
    /** 偏度（与 Excel SKEW 一致） */
    skewness: number;
    /** 超额峰度（与 Excel KURT 一致，正态分布为 0） */
    kurtosis: number;
}

export interface BinDatum {
    x0: number;
    x1: number;
    count: number;
    /** 落入该区间的原始样本索引 */
    indices: number[];
}

export interface BinResult {
    bins: BinDatum[];
    binWidth: number;
    domainMin: number;
    domainMax: number;
}

export interface KdePoint {
    x: number;
    y: number;
}

const EMPTY_STATS: SummaryStats = {
    count: 0, sum: 0, mean: NaN, median: NaN, variance: NaN, std: NaN,
    min: NaN, max: NaN, range: NaN, p10: NaN, p25: NaN, p75: NaN, p90: NaN,
    iqr: NaN, cv: NaN, vsf: NaN, skewness: NaN, kurtosis: NaN
};

/** 线性插值分位数（等同 Excel PERCENTILE.INC） */
export function percentile(sorted: number[], p: number): number {
    const n = sorted.length;
    if (n === 0) {
        return NaN;
    }
    if (n === 1) {
        return sorted[0];
    }
    const idx = (n - 1) * Math.min(1, Math.max(0, p));
    const lo = Math.floor(idx);
    const hi = Math.ceil(idx);
    const frac = idx - lo;
    return sorted[lo] + (sorted[hi] - sorted[lo]) * frac;
}

export function computeStats(values: number[]): SummaryStats {
    const n = values.length;
    if (n === 0) {
        return { ...EMPTY_STATS };
    }

    const sorted = values.slice().sort((a, b) => a - b);

    let sum = 0;
    for (let i = 0; i < n; i++) {
        sum += values[i];
    }
    const mean = sum / n;

    let m2 = 0;
    let m3 = 0;
    let m4 = 0;
    for (let i = 0; i < n; i++) {
        const d = values[i] - mean;
        const d2 = d * d;
        m2 += d2;
        m3 += d2 * d;
        m4 += d2 * d2;
    }

    const variance = n > 1 ? m2 / (n - 1) : 0;
    const std = Math.sqrt(variance);

    const median = percentile(sorted, 0.5);
    const p25 = percentile(sorted, 0.25);
    const p75 = percentile(sorted, 0.75);

    let skewness = NaN;
    if (n > 2 && std > 0) {
        const s3 = Math.pow(std, 3);
        skewness = (n / ((n - 1) * (n - 2))) * (m3 / s3);
    } else if (n > 2) {
        skewness = 0;
    }

    let kurtosis = NaN;
    if (n > 3 && std > 0) {
        const s4 = Math.pow(std, 4);
        kurtosis = (n * (n + 1) / ((n - 1) * (n - 2) * (n - 3))) * (m4 / s4)
            - (3 * (n - 1) * (n - 1)) / ((n - 2) * (n - 3));
    } else if (n > 3) {
        kurtosis = 0;
    }

    const min = sorted[0];
    const max = sorted[n - 1];

    return {
        count: n,
        sum: sum,
        mean: mean,
        median: median,
        variance: variance,
        std: std,
        min: min,
        max: max,
        range: max - min,
        p10: percentile(sorted, 0.1),
        p25: p25,
        p75: p75,
        p90: percentile(sorted, 0.9),
        iqr: p75 - p25,
        cv: mean === 0 ? NaN : std / mean,
        vsf: median === 0 ? NaN : std / median,
        skewness: skewness,
        kurtosis: kurtosis
    };
}

/**
 * 等宽分箱。domain 由数据的最小/最大值确定；当所有值相同时会人为扩展一个小范围。
 */
export function computeBins(values: number[], binCount: number, binWidthOverride?: number): BinResult {
    const n = values.length;
    const count = Math.max(1, Math.min(500, Math.floor(binCount) || 30));

    if (n === 0) {
        return { bins: [], binWidth: 0, domainMin: 0, domainMax: 1 };
    }

    let domainMin = Infinity;
    let domainMax = -Infinity;
    for (let i = 0; i < n; i++) {
        const v = values[i];
        if (v < domainMin) {
            domainMin = v;
        }
        if (v > domainMax) {
            domainMax = v;
        }
    }

    if (!isFinite(domainMin) || !isFinite(domainMax)) {
        return { bins: [], binWidth: 0, domainMin: 0, domainMax: 1 };
    }

    if (domainMax === domainMin) {
        const pad = Math.abs(domainMin) > 0 ? Math.abs(domainMin) * 0.05 : 0.5;
        domainMin -= pad;
        domainMax += pad;
    }

    const binWidth = binWidthOverride && binWidthOverride > 0
        ? binWidthOverride
        : (domainMax - domainMin) / count;

    const bins: BinDatum[] = [];
    for (let i = 0; i < count; i++) {
        bins.push({
            x0: domainMin + i * binWidth,
            x1: domainMin + (i + 1) * binWidth,
            count: 0,
            indices: []
        });
    }

    for (let i = 0; i < n; i++) {
        const v = values[i];
        let idx = Math.floor((v - domainMin) / binWidth);
        if (idx < 0) {
            idx = 0;
        }
        if (idx > count - 1) {
            idx = count - 1;
        }
        bins[idx].count++;
        bins[idx].indices.push(i);
    }

    return {
        bins: bins,
        binWidth: binWidth,
        domainMin: domainMin,
        domainMax: domainMin + count * binWidth
    };
}

/** Silverman 经验法则带宽 */
export function silvermanBandwidth(values: number[], stats: SummaryStats): number {
    const n = stats.count;
    if (n < 2) {
        return 0;
    }
    const sd = stats.std;
    const iqrTerm = stats.iqr > 0 ? stats.iqr / 1.34 : sd;
    const base = Math.min(sd > 0 ? sd : iqrTerm, iqrTerm > 0 ? iqrTerm : sd);
    const h = 0.9 * (base > 0 ? base : 1) * Math.pow(n, -0.2);
    return isFinite(h) && h > 0 ? h : 0;
}

/**
 * 高斯核密度估计，返回密度值（概率密度，未按样本量缩放）。
 */
export function computeKde(
    values: number[],
    bandwidth: number,
    domainMin: number,
    domainMax: number,
    points: number = 200
): KdePoint[] {
    const n = values.length;
    if (n === 0 || !(bandwidth > 0) || !(domainMax > domainMin)) {
        return [];
    }

    const step = (domainMax - domainMin) / Math.max(1, points - 1);
    const norm = 1 / (n * bandwidth * Math.sqrt(2 * Math.PI));
    const inv2h2 = 1 / (2 * bandwidth * bandwidth);
    const result: KdePoint[] = [];

    for (let i = 0; i < points; i++) {
        const x = domainMin + i * step;
        let sum = 0;
        for (let j = 0; j < n; j++) {
            const d = x - values[j];
            sum += Math.exp(-d * d * inv2h2);
        }
        result.push({ x: x, y: sum * norm });
    }

    return result;
}

/** 计算"好看"的刻度步长，行为与 d3.tickStep 一致 */
export function tickStep(start: number, stop: number, count: number): number {
    const step0 = Math.abs(stop - start) / Math.max(1, count);
    if (!(step0 > 0) || !isFinite(step0)) {
        return 1;
    }
    const step1 = Math.pow(10, Math.floor(Math.log(step0) / Math.LN10));
    const error = step0 / step1;
    if (error >= Math.sqrt(50)) {
        return step1 * 10;
    }
    if (error >= Math.sqrt(10)) {
        return step1 * 5;
    }
    if (error >= Math.sqrt(2)) {
        return step1 * 2;
    }
    return step1;
}

export function ticks(start: number, stop: number, count: number): number[] {
    const step = tickStep(start, stop, count);
    const result: number[] = [];
    const first = Math.ceil(start / step) * step;
    const precision = Math.max(0, -Math.floor(Math.log(step) / Math.LN10) + 1);
    for (let v = first, i = 0; v <= stop + step * 1e-6 && i < 1000; v += step, i++) {
        result.push(Number(v.toFixed(precision)));
    }
    return result;
}

/** 向上取整到"好看"的刻度边界 */
export function niceCeil(value: number, count: number = 5): number {
    if (!(value > 0)) {
        return 1;
    }
    const step = tickStep(0, value, count);
    return Math.ceil(value / step) * step;
}
