var intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 439
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ buildFormattingModel)
/* harmony export */ });
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(473);


function desc(objectName, propertyName) {
    return { objectName: objectName, propertyName: propertyName };
}
function slice(uid, displayName, control) {
    return { uid: uid, displayName: displayName, control: control };
}
function numUpDown(objectName, propertyName, displayName, value, min, max, unitSymbol) {
    const options = {};
    if (min !== undefined) {
        options.minValue = { type: 0, value: min };
    }
    if (max !== undefined) {
        options.maxValue = { type: 1, value: max };
    }
    if (unitSymbol) {
        options.unitSymbol = unitSymbol;
    }
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "NumUpDown",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value,
            options: options
        }
    });
}
function slider(objectName, propertyName, displayName, value, min, max, unitSymbol) {
    const options = {
        minValue: { type: 0, value: min },
        maxValue: { type: 1, value: max }
    };
    if (unitSymbol) {
        options.unitSymbol = unitSymbol;
    }
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "Slider",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value,
            options: options
        }
    });
}
function toggle(objectName, propertyName, displayName, value) {
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "ToggleSwitch",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value
        }
    });
}
function colorPicker(objectName, propertyName, displayName, value) {
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "ColorPicker",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: { value: value }
        }
    });
}
function textInput(objectName, propertyName, displayName, value, placeholder) {
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "TextInput",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: value,
            placeholder: placeholder
        }
    });
}
function dropdown(objectName, propertyName, displayName, value, items) {
    const current = items.filter(i => i.value === value)[0] || items[0];
    return slice(`${objectName}_${propertyName}`, displayName, {
        type: "Dropdown",
        properties: {
            descriptor: desc(objectName, propertyName),
            value: { value: current.value, displayName: current.displayName },
            items: items
        }
    });
}
const LINE_STYLE_ITEMS = [
    { value: "solid", displayName: "实线" },
    { value: "dash", displayName: "虚线" },
    { value: "dot", displayName: "点线" },
    { value: "dashDot", displayName: "点划线" }
];
const POSITION_ITEMS = [
    { value: "topRight", displayName: "右上角" },
    { value: "topLeft", displayName: "左上角" },
    { value: "bottomRight", displayName: "右下角" },
    { value: "bottomLeft", displayName: "左下角" }
];
const ANGLE_ITEMS = [
    { value: "0", displayName: "水平 0°" },
    { value: "45", displayName: "倾斜 45°" },
    { value: "90", displayName: "垂直 90°" }
];
function group(uid, displayName, slices, topLevelToggleDescriptor, collapsible) {
    const g = {
        uid: uid,
        displayName: displayName,
        slices: slices
    };
    if (topLevelToggleDescriptor) {
        g.topLevelToggle = {
            uid: `${uid}_toggle`,
            suppressDisplayName: true,
            control: {
                type: "ToggleSwitch",
                properties: {
                    descriptor: desc(topLevelToggleDescriptor.objectName, topLevelToggleDescriptor.propertyName),
                    value: topLevelToggleDescriptor.value
                }
            }
        };
    }
    if (collapsible !== undefined) {
        g.collapsible = collapsible;
    }
    return g;
}
function buildFormattingModel(settings, themeColor) {
    const s = settings;
    const cards = [];
    /* ---------------- 柱形与分箱 ---------------- */
    cards.push({
        uid: "card_bins",
        displayName: "分箱与柱形",
        groups: [
            group("group_bins", "数据分箱", [
                slider("bins", "binCount", "区间数量", s.binCount, 2, 200)
            ]),
            group("group_bars", "柱形", [
                colorPicker("bars", "fillColor", "填充颜色", s.barFillSet && s.barFill ? s.barFill : themeColor),
                slider("bars", "transparency", "透明度", s.barTransparency, 0, 100, "%"),
                numUpDown("bars", "gap", "柱间距", s.barGap, 0, 0.8),
                numUpDown("bars", "cornerRadius", "圆角半径", s.barRadius, 0, 20, "px"),
                toggle("bars", "showBorder", "显示描边", s.barBorder),
                colorPicker("bars", "borderColor", "描边颜色", s.barBorderColor)
            ])
        ]
    });
    /* ---------------- 常量线 ---------------- */
    const lineGroups = [];
    for (const def of _settings__WEBPACK_IMPORTED_MODULE_0__/* .LINE_DEFINITIONS */ .yJ) {
        const ls = s.lines[def.key];
        lineGroups.push(group(`group_${def.objectName}`, def.label, [
            colorPicker(def.objectName, "lineColor", "颜色", ls.color),
            numUpDown(def.objectName, "lineWidth", "粗细", ls.width, 0.5, 8, "px"),
            dropdown(def.objectName, "lineStyle", "线型", ls.style, LINE_STYLE_ITEMS),
            toggle(def.objectName, "showLabel", "显示名称与值", ls.showLabel)
        ], { objectName: def.objectName, propertyName: "show", value: ls.show }, true));
    }
    cards.push({
        uid: "card_lines",
        displayName: "常量参考线",
        groups: lineGroups
    });
    /* ---------------- KDE ---------------- */
    cards.push({
        uid: "card_kde",
        displayName: "KDE 密度曲线",
        groups: [
            group("group_kde", "密度曲线", [
                colorPicker("kde", "lineColor", "颜色", s.kdeColor),
                numUpDown("kde", "lineWidth", "粗细", s.kdeWidth, 0.5, 8, "px"),
                dropdown("kde", "lineStyle", "线型", s.kdeStyle, LINE_STYLE_ITEMS),
                numUpDown("kde", "bandwidth", "带宽倍数", s.kdeBandwidth, 0.1, 4),
                toggle("kde", "showArea", "曲线下方填充", s.kdeShowArea),
                slider("kde", "areaTransparency", "填充透明度", s.kdeAreaTransparency, 0, 100, "%")
            ], { objectName: "kde", propertyName: "show", value: s.kdeShow })
        ]
    });
    /* ---------------- 坐标轴 ---------------- */
    cards.push({
        uid: "card_axes",
        displayName: "坐标轴与标签",
        groups: [
            group("group_axis_visibility", "坐标轴", [
                toggle("axes", "showXAxis", "显示 X 轴", s.showXAxis),
                toggle("axes", "showYAxis", "显示 Y 轴", s.showYAxis),
                toggle("axes", "showGridlines", "显示横向网格线", s.showGridlines),
                colorPicker("axes", "gridlineColor", "网格线颜色", s.gridlineColor),
                toggle("axes", "yFromZero", "Y 轴从 0 开始", s.yFromZero)
            ]),
            group("group_axis_titles", "轴标题", [
                toggle("axes", "showXTitle", "显示 X 轴标题", s.showXTitle),
                textInput("axes", "xTitle", "X 轴标题", s.xTitle, "区间"),
                toggle("axes", "showYTitle", "显示 Y 轴标题", s.showYTitle),
                textInput("axes", "yTitle", "Y 轴标题", s.yTitle, "计数")
            ]),
            group("group_axis_format", "标签格式", [
                dropdown("axes", "labelAngle", "X 轴刻度角度", String(s.labelAngle), ANGLE_ITEMS),
                numUpDown("axes", "axisFontSize", "刻度字号", s.axisFontSize, 6, 24, "pt"),
                numUpDown("axes", "titleFontSize", "标题字号", s.titleFontSize, 6, 28, "pt"),
                colorPicker("axes", "labelColor", "标签颜色", s.labelColor),
                colorPicker("axes", "axisColor", "轴线颜色", s.axisColor)
            ])
        ]
    });
    /* ---------------- 统计量图例 ---------------- */
    const statSlices = _settings__WEBPACK_IMPORTED_MODULE_0__/* .STAT_LABELS */ .Zh.map(item => toggle("stats", item.key, item.label, s.statsVisible[item.key]));
    cards.push({
        uid: "card_stats",
        displayName: "统计量图例",
        groups: [
            group("group_stats_layout", "布局", [
                dropdown("stats", "position", "位置", s.statsPosition, POSITION_ITEMS),
                numUpDown("stats", "columns", "列数", s.statsColumns, 1, 3),
                numUpDown("stats", "fontSize", "字号", s.statsFontSize, 6, 24, "pt"),
                numUpDown("stats", "decimals", "小数位", s.statsDecimals, 0, 6)
            ]),
            group("group_stats_style", "外观", [
                colorPicker("stats", "fontColor", "文字颜色", s.statsFontColor),
                colorPicker("stats", "backgroundColor", "背景颜色", s.statsBackground),
                slider("stats", "transparency", "背景透明度", s.statsTransparency, 0, 100, "%"),
                toggle("stats", "showBorder", "显示边框", s.statsShowBorder),
                colorPicker("stats", "borderColor", "边框颜色", s.statsBorderColor)
            ]),
            group("group_stats_items", "显示哪些统计量", statSlices, undefined)
        ],
        // 卡片级开关：图例总开关
        topLevelToggle: {
            uid: "stats_card_toggle",
            suppressDisplayName: true,
            control: {
                type: "ToggleSwitch",
                properties: {
                    descriptor: desc("stats", "show"),
                    value: s.statsShow
                }
            }
        }
    });
    return { cards: cards };
}


/***/ },

/***/ 473
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   wB: () => (/* binding */ Settings)
/* harmony export */ });
/* unused harmony export DEFAULT_STAT_VISIBILITY */

const LINE_DEFINITIONS = [
    {
        objectName: "m3Sigma", key: "m3", label: "均值 -3σ", defaultColor: "#8E44AD",
        defaultShow: true, defaultWidth: 1, defaultStyle: "dash",
        value: (s) => s.mean - 3 * s.std
    },
    {
        objectName: "m2Sigma", key: "m2", label: "均值 -2σ", defaultColor: "#16A085",
        defaultShow: false, defaultWidth: 1, defaultStyle: "dash",
        value: (s) => s.mean - 2 * s.std
    },
    {
        objectName: "m1Sigma", key: "m1", label: "均值 -1σ", defaultColor: "#E67E22",
        defaultShow: true, defaultWidth: 1, defaultStyle: "dash",
        value: (s) => s.mean - s.std
    },
    {
        objectName: "sigmaLine", key: "sigma", label: "标准差 σ", defaultColor: "#8C8C8C",
        defaultShow: false, defaultWidth: 1, defaultStyle: "dot",
        value: (s) => s.std
    },
    {
        objectName: "medianLine", key: "median", label: "中位数", defaultColor: "#1F6FB2",
        defaultShow: true, defaultWidth: 1.5, defaultStyle: "solid",
        value: (s) => s.median
    },
    {
        objectName: "meanLine", key: "mean", label: "均值", defaultColor: "#C0392B",
        defaultShow: true, defaultWidth: 1.5, defaultStyle: "solid",
        value: (s) => s.mean
    },
    {
        objectName: "p1Sigma", key: "p1", label: "均值 +1σ", defaultColor: "#E67E22",
        defaultShow: true, defaultWidth: 1, defaultStyle: "solid",
        value: (s) => s.mean + s.std
    },
    {
        objectName: "p2Sigma", key: "p2", label: "均值 +2σ", defaultColor: "#16A085",
        defaultShow: false, defaultWidth: 1, defaultStyle: "solid",
        value: (s) => s.mean + 2 * s.std
    },
    {
        objectName: "p3Sigma", key: "p3", label: "均值 +3σ", defaultColor: "#8E44AD",
        defaultShow: true, defaultWidth: 1, defaultStyle: "solid",
        value: (s) => s.mean + 3 * s.std
    }
];
const STAT_LABELS = [
    { key: "mean", label: "均值" },
    { key: "median", label: "中位数" },
    { key: "std", label: "标准差" },
    { key: "variance", label: "方差" },
    { key: "count", label: "计数" },
    { key: "max", label: "最大值" },
    { key: "min", label: "最小值" },
    { key: "cv", label: "CV" },
    { key: "vsf", label: "VSF" },
    { key: "skewness", label: "偏度" },
    { key: "kurtosis", label: "峰度" },
    { key: "p25", label: "P25" },
    { key: "p75", label: "P75" },
    { key: "p90", label: "P90" },
    { key: "p10", label: "P10" }
];
const DEFAULT_STAT_VISIBILITY = {
    mean: true,
    median: true,
    std: true,
    variance: false,
    count: true,
    max: false,
    min: false,
    cv: false,
    vsf: false,
    skewness: false,
    kurtosis: false,
    p25: false,
    p75: false,
    p90: false,
    p10: false
};
function getObject(dataView, objectName) {
    const objects = dataView && dataView.metadata ? dataView.metadata.objects : null;
    if (!objects) {
        return null;
    }
    return objects[objectName] || null;
}
function num(obj, prop, def) {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null || v === "") {
        return def;
    }
    const parsed = typeof v === "number" ? v : parseFloat(v);
    return isFinite(parsed) ? parsed : def;
}
function bool(obj, prop, def) {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null) {
        return def;
    }
    if (typeof v === "boolean") {
        return v;
    }
    return String(v).toLowerCase() === "true";
}
function str(obj, prop, def) {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null) {
        return def;
    }
    return String(v);
}
/** Power BI 的颜色属性可能是 { solid: { color } } 对象，也可能直接是字符串 */
function color(obj, prop, def) {
    const v = obj ? obj[prop] : undefined;
    if (v === undefined || v === null) {
        return def;
    }
    if (typeof v === "string") {
        return v;
    }
    if (v.solid && v.solid.color) {
        return v.solid.color;
    }
    return def;
}
function hasColor(obj, prop) {
    const v = obj ? obj[prop] : undefined;
    return !!(v && (typeof v === "string" || (v.solid && v.solid.color)));
}
function clamp(v, min, max) {
    return v < min ? min : (v > max ? max : v);
}
class Settings {
    constructor() {
        // 分箱
        this.binCount = 30;
        // 柱形
        this.barFill = "";
        this.barFillSet = false;
        this.barTransparency = 0;
        this.barGap = 0.08;
        this.barRadius = 2;
        this.barBorder = false;
        this.barBorderColor = "#FFFFFF";
        // 常量线
        this.lines = {};
        // KDE
        this.kdeShow = true;
        this.kdeColor = "#2C7BE5";
        this.kdeWidth = 2;
        this.kdeStyle = "solid";
        this.kdeBandwidth = 1;
        this.kdeShowArea = false;
        this.kdeAreaTransparency = 88;
        // 坐标轴
        this.showXAxis = true;
        this.showYAxis = true;
        this.showXTitle = true;
        this.xTitle = "区间";
        this.showYTitle = true;
        this.yTitle = "计数";
        this.labelAngle = 0;
        this.axisFontSize = 10;
        this.titleFontSize = 11;
        this.axisColor = "#B3B0AD";
        this.labelColor = "#605E5C";
        this.showGridlines = true;
        this.gridlineColor = "#EDEBE9";
        this.yFromZero = true;
        // 统计量图例
        this.statsShow = true;
        this.statsPosition = "topRight";
        this.statsColumns = 2;
        this.statsFontSize = 10;
        this.statsFontColor = "#323130";
        this.statsBackground = "#FFFFFF";
        this.statsTransparency = 15;
        this.statsShowBorder = true;
        this.statsBorderColor = "#E1DFDD";
        this.statsDecimals = 2;
        this.statsVisible = Object.assign({}, DEFAULT_STAT_VISIBILITY);
    }
    static parse(dataView) {
        const s = new Settings();
        if (!dataView) {
            return s;
        }
        const bins = getObject(dataView, "bins");
        s.binCount = Math.round(clamp(num(bins, "binCount", 30), 2, 500));
        const bars = getObject(dataView, "bars");
        s.barFillSet = hasColor(bars, "fillColor");
        s.barFill = color(bars, "fillColor", "");
        s.barTransparency = clamp(num(bars, "transparency", 0), 0, 100);
        s.barGap = clamp(num(bars, "gap", 0.08), 0, 0.85);
        s.barRadius = clamp(num(bars, "cornerRadius", 2), 0, 20);
        s.barBorder = bool(bars, "showBorder", false);
        s.barBorderColor = color(bars, "borderColor", "#FFFFFF");
        const lineMap = {};
        for (const def of LINE_DEFINITIONS) {
            const o = getObject(dataView, def.objectName);
            lineMap[def.key] = {
                show: bool(o, "show", def.defaultShow),
                color: color(o, "lineColor", def.defaultColor),
                width: clamp(num(o, "lineWidth", def.defaultWidth), 0.5, 8),
                style: str(o, "lineStyle", def.defaultStyle),
                showLabel: bool(o, "showLabel", true)
            };
        }
        s.lines = lineMap;
        const kde = getObject(dataView, "kde");
        s.kdeShow = bool(kde, "show", true);
        s.kdeColor = color(kde, "lineColor", "#2C7BE5");
        s.kdeWidth = clamp(num(kde, "lineWidth", 2), 0.5, 8);
        s.kdeStyle = str(kde, "lineStyle", "solid");
        s.kdeBandwidth = clamp(num(kde, "bandwidth", 1), 0.1, 4);
        s.kdeShowArea = bool(kde, "showArea", false);
        s.kdeAreaTransparency = clamp(num(kde, "areaTransparency", 88), 0, 100);
        const axes = getObject(dataView, "axes");
        s.showXAxis = bool(axes, "showXAxis", true);
        s.showYAxis = bool(axes, "showYAxis", true);
        s.showXTitle = bool(axes, "showXTitle", true);
        s.xTitle = str(axes, "xTitle", "区间");
        s.showYTitle = bool(axes, "showYTitle", true);
        s.yTitle = str(axes, "yTitle", "计数");
        s.labelAngle = clamp(num(axes, "labelAngle", 0), 0, 90);
        s.axisFontSize = clamp(num(axes, "axisFontSize", 10), 6, 24);
        s.titleFontSize = clamp(num(axes, "titleFontSize", 11), 6, 28);
        s.axisColor = color(axes, "axisColor", "#B3B0AD");
        s.labelColor = color(axes, "labelColor", "#605E5C");
        s.showGridlines = bool(axes, "showGridlines", true);
        s.gridlineColor = color(axes, "gridlineColor", "#EDEBE9");
        s.yFromZero = bool(axes, "yFromZero", true);
        const st = getObject(dataView, "stats");
        s.statsShow = bool(st, "show", true);
        s.statsPosition = str(st, "position", "topRight");
        if (["topRight", "topLeft", "bottomRight", "bottomLeft"].indexOf(s.statsPosition) < 0) {
            s.statsPosition = "topRight";
        }
        s.statsColumns = Math.round(clamp(num(st, "columns", 2), 1, 3));
        s.statsFontSize = clamp(num(st, "fontSize", 10), 6, 24);
        s.statsFontColor = color(st, "fontColor", "#323130");
        s.statsBackground = color(st, "backgroundColor", "#FFFFFF");
        s.statsTransparency = clamp(num(st, "transparency", 15), 0, 100);
        s.statsShowBorder = bool(st, "showBorder", true);
        s.statsBorderColor = color(st, "borderColor", "#E1DFDD");
        s.statsDecimals = Math.round(clamp(num(st, "decimals", 2), 0, 6));
        const visible = Object.assign({}, DEFAULT_STAT_VISIBILITY);
        for (const item of STAT_LABELS) {
            visible[item.key] = bool(st, item.key, DEFAULT_STAT_VISIBILITY[item.key]);
        }
        s.statsVisible = visible;
        return s;
    }
}

/* harmony export */ __webpack_require__.d(__webpack_exports__, [
/* harmony export */   "Zh", 0, /* binding */ STAT_LABELS,
/* harmony export */   "yJ", 0, /* binding */ LINE_DEFINITIONS
/* harmony export */ ]);


/***/ },

/***/ 589
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D7: () => (/* binding */ silvermanBandwidth),
/* harmony export */   Id: () => (/* binding */ computeBins),
/* harmony export */   Zc: () => (/* binding */ ticks),
/* harmony export */   bV: () => (/* binding */ computeStats),
/* harmony export */   ec: () => (/* binding */ computeKde),
/* harmony export */   nF: () => (/* binding */ niceCeil),
/* harmony export */   sG: () => (/* binding */ tickStep)
/* harmony export */ });
/* unused harmony export percentile */

const EMPTY_STATS = {
    count: 0, sum: 0, mean: NaN, median: NaN, variance: NaN, std: NaN,
    min: NaN, max: NaN, range: NaN, p10: NaN, p25: NaN, p75: NaN, p90: NaN,
    iqr: NaN, cv: NaN, vsf: NaN, skewness: NaN, kurtosis: NaN
};
/** 线性插值分位数（等同 Excel PERCENTILE.INC） */
function percentile(sorted, p) {
    const n = sorted.length;
    if (n === 0) {
        return NaN;
    }
    if (n === 1) {
        return sorted[0];
    }
    const idx = (n - 1) * Math.min(1, Math.max(0, p));
    const lo = Math.floor(idx);
    const hi = Math.ceil(idx);
    const frac = idx - lo;
    return sorted[lo] + (sorted[hi] - sorted[lo]) * frac;
}
function computeStats(values) {
    const n = values.length;
    if (n === 0) {
        return Object.assign({}, EMPTY_STATS);
    }
    const sorted = values.slice().sort((a, b) => a - b);
    let sum = 0;
    for (let i = 0; i < n; i++) {
        sum += values[i];
    }
    const mean = sum / n;
    let m2 = 0;
    let m3 = 0;
    let m4 = 0;
    for (let i = 0; i < n; i++) {
        const d = values[i] - mean;
        const d2 = d * d;
        m2 += d2;
        m3 += d2 * d;
        m4 += d2 * d2;
    }
    const variance = n > 1 ? m2 / (n - 1) : 0;
    const std = Math.sqrt(variance);
    const median = percentile(sorted, 0.5);
    const p25 = percentile(sorted, 0.25);
    const p75 = percentile(sorted, 0.75);
    let skewness = NaN;
    if (n > 2 && std > 0) {
        const s3 = Math.pow(std, 3);
        skewness = (n / ((n - 1) * (n - 2))) * (m3 / s3);
    }
    else if (n > 2) {
        skewness = 0;
    }
    let kurtosis = NaN;
    if (n > 3 && std > 0) {
        const s4 = Math.pow(std, 4);
        kurtosis = (n * (n + 1) / ((n - 1) * (n - 2) * (n - 3))) * (m4 / s4)
            - (3 * (n - 1) * (n - 1)) / ((n - 2) * (n - 3));
    }
    else if (n > 3) {
        kurtosis = 0;
    }
    const min = sorted[0];
    const max = sorted[n - 1];
    return {
        count: n,
        sum: sum,
        mean: mean,
        median: median,
        variance: variance,
        std: std,
        min: min,
        max: max,
        range: max - min,
        p10: percentile(sorted, 0.1),
        p25: p25,
        p75: p75,
        p90: percentile(sorted, 0.9),
        iqr: p75 - p25,
        cv: mean === 0 ? NaN : std / mean,
        vsf: median === 0 ? NaN : std / median,
        skewness: skewness,
        kurtosis: kurtosis
    };
}
/**
 * 等宽分箱。domain 由数据的最小/最大值确定；当所有值相同时会人为扩展一个小范围。
 */
function computeBins(values, binCount, binWidthOverride) {
    const n = values.length;
    const count = Math.max(1, Math.min(500, Math.floor(binCount) || 30));
    if (n === 0) {
        return { bins: [], binWidth: 0, domainMin: 0, domainMax: 1 };
    }
    let domainMin = Infinity;
    let domainMax = -Infinity;
    for (let i = 0; i < n; i++) {
        const v = values[i];
        if (v < domainMin) {
            domainMin = v;
        }
        if (v > domainMax) {
            domainMax = v;
        }
    }
    if (!isFinite(domainMin) || !isFinite(domainMax)) {
        return { bins: [], binWidth: 0, domainMin: 0, domainMax: 1 };
    }
    if (domainMax === domainMin) {
        const pad = Math.abs(domainMin) > 0 ? Math.abs(domainMin) * 0.05 : 0.5;
        domainMin -= pad;
        domainMax += pad;
    }
    const binWidth = binWidthOverride && binWidthOverride > 0
        ? binWidthOverride
        : (domainMax - domainMin) / count;
    const bins = [];
    for (let i = 0; i < count; i++) {
        bins.push({
            x0: domainMin + i * binWidth,
            x1: domainMin + (i + 1) * binWidth,
            count: 0,
            indices: []
        });
    }
    for (let i = 0; i < n; i++) {
        const v = values[i];
        let idx = Math.floor((v - domainMin) / binWidth);
        if (idx < 0) {
            idx = 0;
        }
        if (idx > count - 1) {
            idx = count - 1;
        }
        bins[idx].count++;
        bins[idx].indices.push(i);
    }
    return {
        bins: bins,
        binWidth: binWidth,
        domainMin: domainMin,
        domainMax: domainMin + count * binWidth
    };
}
/** Silverman 经验法则带宽 */
function silvermanBandwidth(values, stats) {
    const n = stats.count;
    if (n < 2) {
        return 0;
    }
    const sd = stats.std;
    const iqrTerm = stats.iqr > 0 ? stats.iqr / 1.34 : sd;
    const base = Math.min(sd > 0 ? sd : iqrTerm, iqrTerm > 0 ? iqrTerm : sd);
    const h = 0.9 * (base > 0 ? base : 1) * Math.pow(n, -0.2);
    return isFinite(h) && h > 0 ? h : 0;
}
/**
 * 高斯核密度估计，返回密度值（概率密度，未按样本量缩放）。
 */
function computeKde(values, bandwidth, domainMin, domainMax, points = 200) {
    const n = values.length;
    if (n === 0 || !(bandwidth > 0) || !(domainMax > domainMin)) {
        return [];
    }
    const step = (domainMax - domainMin) / Math.max(1, points - 1);
    const norm = 1 / (n * bandwidth * Math.sqrt(2 * Math.PI));
    const inv2h2 = 1 / (2 * bandwidth * bandwidth);
    const result = [];
    for (let i = 0; i < points; i++) {
        const x = domainMin + i * step;
        let sum = 0;
        for (let j = 0; j < n; j++) {
            const d = x - values[j];
            sum += Math.exp(-d * d * inv2h2);
        }
        result.push({ x: x, y: sum * norm });
    }
    return result;
}
/** 计算"好看"的刻度步长，行为与 d3.tickStep 一致 */
function tickStep(start, stop, count) {
    const step0 = Math.abs(stop - start) / Math.max(1, count);
    if (!(step0 > 0) || !isFinite(step0)) {
        return 1;
    }
    const step1 = Math.pow(10, Math.floor(Math.log(step0) / Math.LN10));
    const error = step0 / step1;
    if (error >= Math.sqrt(50)) {
        return step1 * 10;
    }
    if (error >= Math.sqrt(10)) {
        return step1 * 5;
    }
    if (error >= Math.sqrt(2)) {
        return step1 * 2;
    }
    return step1;
}
function ticks(start, stop, count) {
    const step = tickStep(start, stop, count);
    const result = [];
    const first = Math.ceil(start / step) * step;
    const precision = Math.max(0, -Math.floor(Math.log(step) / Math.LN10) + 1);
    for (let v = first, i = 0; v <= stop + step * 1e-6 && i < 1000; v += step, i++) {
        result.push(Number(v.toFixed(precision)));
    }
    return result;
}
/** 向上取整到"好看"的刻度边界 */
function niceCeil(value, count = 5) {
    if (!(value > 0)) {
        return 1;
    }
    const step = tickStep(0, value, count);
    return Math.ceil(value / step) * step;
}


/***/ },

/***/ 848
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ Visual)
/* harmony export */ });
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(473);
/* harmony import */ var _formatting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(439);
/* harmony import */ var _stats__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(589);





const NS = "http://www.w3.org/2000/svg";
/* ------------------------------------------------------------------ */
/* 通用小工具                                                          */
/* ------------------------------------------------------------------ */
function el(tag, attrs, parent) {
    const node = document.createElementNS(NS, tag);
    if (attrs) {
        for (const key in attrs) {
            const v = attrs[key];
            if (v !== undefined && v !== null && v !== "") {
                node.setAttribute(key, String(v));
            }
        }
    }
    if (parent) {
        parent.appendChild(node);
    }
    return node;
}
function clearNode(node) {
    while (node.firstChild) {
        node.removeChild(node.firstChild);
    }
}
function clamp(v, min, max) {
    return v < min ? min : (v > max ? max : v);
}
/** 粗略估算文本宽度：中日韩字符按 1em，其余按 0.56em */
function estimateTextWidth(text, fontSize) {
    let w = 0;
    for (let i = 0; i < text.length; i++) {
        const code = text.charCodeAt(i);
        w += (code > 0x2e80 && code < 0xa4d0) ? 1.0 : 0.56;
    }
    return w * fontSize;
}
function formatNumber(v, decimals) {
    if (!isFinite(v)) {
        return "—";
    }
    try {
        return new Intl.NumberFormat("en-US", {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        }).format(v);
    }
    catch (e) {
        return v.toFixed(decimals);
    }
}
function formatTickValue(v, step) {
    if (!isFinite(v)) {
        return "";
    }
    const decimals = step >= 1 ? 0 : Math.min(6, Math.ceil(-Math.log10(step)));
    return formatNumber(v, decimals);
}
function dashArray(style, width) {
    switch (style) {
        case "dash":
            return `${Math.max(4, width * 5)} ${Math.max(3, width * 3)}`;
        case "dot":
            return `${Math.max(1, width)} ${Math.max(2.5, width * 2)}`;
        case "dashDot":
            return `${Math.max(5, width * 6)} ${Math.max(2.5, width * 2)} ${Math.max(1, width)} ${Math.max(2.5, width * 2)}`;
        default:
            return "none";
    }
}
function toPowerBiColor(hex) {
    return { solid: { color: hex } };
}
/* ------------------------------------------------------------------ */
/* 数据建模                                                            */
/* ------------------------------------------------------------------ */
function countIntoBins(values, binWidth, domainMin, binCount) {
    const counts = new Array(binCount);
    for (let i = 0; i < binCount; i++) {
        counts[i] = 0;
    }
    if (!(binWidth > 0)) {
        return counts;
    }
    for (let i = 0; i < values.length; i++) {
        let idx = Math.floor((values[i] - domainMin) / binWidth);
        if (idx < 0) {
            idx = 0;
        }
        if (idx > binCount - 1) {
            idx = binCount - 1;
        }
        counts[idx]++;
    }
    return counts;
}
function buildViewModel(dataView, settings) {
    const empty = (msg) => ({
        values: [], rowIndices: [], categoryColumn: null, valueColumn: null,
        highlightValues: [], hasHighlight: false, highlightBins: [],
        stats: (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .computeStats */ .bV)([]), bins: [], binWidth: 0, domainMin: 0, domainMax: 1,
        kde: [], kdeBandwidth: 0, emptyMessage: msg
    });
    if (!dataView || !dataView.categorical) {
        return empty("请将「类别」字段（文本或日期）和「值」字段（数值或度量值）拖入字段槽位");
    }
    const categorical = dataView.categorical;
    const values = categorical.values;
    if (!values || !values.length) {
        return empty("请添加「值」字段（数值或度量值）");
    }
    const valueColumn = values[0];
    const categoryColumn = categorical.categories && categorical.categories.length
        ? categorical.categories[0]
        : null;
    const raw = valueColumn.values || [];
    const rawHighlight = valueColumn.highlights || null;
    const nums = [];
    const rowIndices = [];
    let hasHighlight = false;
    for (let i = 0; i < raw.length; i++) {
        const v = raw[i];
        if (typeof v !== "number" || !isFinite(v)) {
            continue;
        }
        nums.push(v);
        rowIndices.push(i);
        if (rawHighlight && rawHighlight.length > i && rawHighlight[i] !== null && rawHighlight[i] !== undefined) {
            hasHighlight = true;
        }
    }
    if (!nums.length) {
        return empty("当前筛选条件下没有可用的数值");
    }
    // 只放了一个度量值（没有类别）时，Power BI 只会给出一行聚合值，直方图没有意义
    if (!categoryColumn && nums.length < 3) {
        return empty("请把文本或日期字段放入「类别」，让每一行作为一个样本参与分布统计");
    }
    const stats = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .computeStats */ .bV)(nums);
    const binResult = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .computeBins */ .Id)(nums, settings.binCount);
    // 高亮（交叉筛选）样本：按同一分箱边界计数
    let highlightBins = [];
    const highlightValues = [];
    if (hasHighlight && rawHighlight) {
        for (let i = 0; i < rawHighlight.length; i++) {
            const v = rawHighlight[i];
            if (typeof v === "number" && isFinite(v)) {
                highlightValues.push(v);
            }
        }
        highlightBins = countIntoBins(highlightValues, binResult.binWidth, binResult.domainMin, binResult.bins.length);
    }
    // KDE
    let kde = [];
    let kdeBandwidth = 0;
    if (stats.count > 2 && stats.std > 0) {
        const base = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .silvermanBandwidth */ .D7)(nums, stats);
        kdeBandwidth = base * settings.kdeBandwidth;
        if (kdeBandwidth > 0) {
            const density = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .computeKde */ .ec)(nums, kdeBandwidth, binResult.domainMin, binResult.domainMax, 220);
            const scale = stats.count * binResult.binWidth;
            kde = density.map(p => ({ x: p.x, y: p.y * scale }));
        }
    }
    return {
        values: nums,
        rowIndices: rowIndices,
        categoryColumn: categoryColumn,
        valueColumn: valueColumn,
        highlightValues: highlightValues,
        hasHighlight: hasHighlight && highlightValues.length > 0,
        highlightBins: highlightBins,
        stats: stats,
        bins: binResult.bins,
        binWidth: binResult.binWidth,
        domainMin: binResult.domainMin,
        domainMax: binResult.domainMax,
        kde: kde,
        kdeBandwidth: kdeBandwidth,
        emptyMessage: ""
    };
}
/* ------------------------------------------------------------------ */
/* 视觉对象                                                            */
/* ------------------------------------------------------------------ */
class Visual {
    constructor(options) {
        this.settings = new _settings__WEBPACK_IMPORTED_MODULE_0__/* .Settings */ .wB();
        this.model = null;
        this.viewport = { width: 0, height: 0 };
        this.plot = { x: 0, y: 0, width: 0, height: 0 };
        this.barNodes = [];
        this.selectedBins = [];
        this.hoverBin = -1;
        this.themeColor = "#2C7BE5";
        this.onClick = (e) => this.handleClick(e);
        this.onMove = (e) => this.handleMouseMove(e);
        this.onLeave = () => this.handleMouseLeave();
        this.host = options.host;
        this.tooltipService = options.host.tooltipService;
        this.selectionManager = options.host.createSelectionManager();
        this.container = document.createElement("div");
        this.container.className = "interval-histogram";
        options.element.appendChild(this.container);
        this.svg = document.createElementNS(NS, "svg");
        this.svg.setAttribute("class", "ih-svg");
        this.container.appendChild(this.svg);
        try {
            this.themeColor = options.host.colorPalette.getColor("intervalHistogram").value;
        }
        catch (e) {
            this.themeColor = "#2C7BE5";
        }
        this.svg.addEventListener("click", this.onClick);
        this.svg.addEventListener("mousemove", this.onMove);
        this.svg.addEventListener("mouseleave", this.onLeave);
    }
    destroy() {
        this.svg.removeEventListener("click", this.onClick);
        this.svg.removeEventListener("mousemove", this.onMove);
        this.svg.removeEventListener("mouseleave", this.onLeave);
    }
    /* --------------------------- 更新 --------------------------- */
    update(options) {
        const dataView = options.dataViews && options.dataViews[0];
        this.settings = _settings__WEBPACK_IMPORTED_MODULE_0__/* .Settings */ .wB.parse(dataView);
        this.viewport = options.viewport || { width: 0, height: 0 };
        const model = buildViewModel(dataView, this.settings);
        // 选择状态在数据变化后可能失效，做一次收敛
        if (!this.selectionManager.hasSelection()) {
            this.selectedBins = [];
        }
        else if (this.selectedBins.length) {
            this.selectedBins = this.selectedBins.filter(i => i < model.bins.length);
        }
        this.model = model;
        this.hoverBin = -1;
        this.render();
    }
    /* --------------------------- 渲染 --------------------------- */
    render() {
        const width = Math.max(0, this.viewport.width);
        const height = Math.max(0, this.viewport.height);
        clearNode(this.svg);
        this.barNodes = [];
        this.svg.setAttribute("width", String(width));
        this.svg.setAttribute("height", String(height));
        this.svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
        const model = this.model;
        if (!model || model.emptyMessage || !model.bins.length) {
            this.renderEmpty(width, height, model ? model.emptyMessage : "");
            return;
        }
        const s = this.settings;
        /* ---------- 计算纵轴范围 ---------- */
        let maxCount = 0;
        for (const b of model.bins) {
            if (b.count > maxCount) {
                maxCount = b.count;
            }
        }
        let kdePeak = 0;
        if (s.kdeShow && model.kde.length) {
            for (const p of model.kde) {
                if (p.y > kdePeak) {
                    kdePeak = p.y;
                }
            }
        }
        const dataPeak = Math.max(maxCount, kdePeak, 1);
        const yTicksCount = 5;
        const yMax = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .niceCeil */ .nF)(dataPeak, yTicksCount);
        let yMin = 0;
        if (!s.yFromZero) {
            let minCount = Infinity;
            for (const b of model.bins) {
                if (b.count < minCount) {
                    minCount = b.count;
                }
            }
            if (!isFinite(minCount)) {
                minCount = 0;
            }
            const stepGuess = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .tickStep */ .sG)(0, yMax, yTicksCount);
            yMin = Math.max(0, Math.floor(minCount / stepGuess) * stepGuess - stepGuess);
            if (yMin > yMax * 0.8) {
                yMin = 0;
            }
        }
        const yTickValues = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .ticks */ .Zc)(yMin, yMax, yTicksCount);
        if (yTickValues.length < 2) {
            yTickValues.push(yMax);
        }
        const yStep = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .tickStep */ .sG)(yMin, yMax, yTicksCount);
        const yLabels = yTickValues.map(v => formatTickValue(v, yStep));
        /* ---------- 边距 ---------- */
        let yLabelWidth = 0;
        for (const label of yLabels) {
            const w = estimateTextWidth(label, s.axisFontSize);
            if (w > yLabelWidth) {
                yLabelWidth = w;
            }
        }
        const padTop = 12;
        const padRight = 14;
        const left = (s.showYAxis ? yLabelWidth + 12 : 6)
            + (s.showYTitle && s.yTitle ? s.titleFontSize + 8 : 0);
        const xLabelHeight = s.labelAngle === 0
            ? s.axisFontSize * 1.45
            : (s.labelAngle === 45 ? s.axisFontSize * 2.9 : s.axisFontSize * 3.4);
        const bottom = 4
            + (s.showXAxis ? xLabelHeight + 4 : 0)
            + (s.showXTitle && s.xTitle ? s.titleFontSize + 10 : 0);
        const plotW = width - left - padRight;
        const plotH = height - padTop - bottom;
        if (plotW < 30 || plotH < 30) {
            this.renderEmpty(width, height, "空间不足，请扩大视觉对象尺寸");
            return;
        }
        const plot = { x: left, y: padTop, width: plotW, height: plotH };
        this.plot = plot;
        const domainSpan = model.domainMax - model.domainMin || 1;
        const ySpan = (yMax - yMin) || 1;
        const sx = (v) => plot.x + ((v - model.domainMin) / domainSpan) * plotW;
        const sy = (c) => plot.y + plotH - ((c - yMin) / ySpan) * plotH;
        const baseY = sy(Math.max(yMin, 0));
        const root = el("g", { class: "ih-root" }, this.svg);
        /* ---------- 网格线 ---------- */
        if (s.showGridlines) {
            const grid = el("g", { class: "ih-grid" }, root);
            for (const v of yTickValues) {
                el("line", {
                    x1: plot.x, x2: plot.x + plotW,
                    y1: sy(v), y2: sy(v),
                    stroke: s.gridlineColor, "stroke-width": 1,
                    "shape-rendering": "crispEdges"
                }, grid);
            }
        }
        /* ---------- 柱形 ---------- */
        const barColor = s.barFillSet && s.barFill ? s.barFill : this.themeColor;
        const opacity = 1 - clamp(s.barTransparency, 0, 100) / 100;
        const binPixelWidth = plotW / model.bins.length;
        const gapPx = binPixelWidth * clamp(s.barGap, 0, 0.85);
        const hasSelection = this.selectionManager.hasSelection() && this.selectedBins.length > 0;
        const highlightActive = model.hasHighlight;
        const barsGroup = el("g", { class: "ih-bars" }, root);
        const overlayGroup = el("g", { class: "ih-bars-highlight" }, root);
        for (let i = 0; i < model.bins.length; i++) {
            const bin = model.bins[i];
            const x = sx(bin.x0) + gapPx / 2;
            const w = Math.max(0.6, sx(bin.x1) - sx(bin.x0) - gapPx);
            const y = sy(bin.count);
            const h = Math.max(0, baseY - y);
            const dimmed = hasSelection && this.selectedBins.indexOf(i) < 0;
            let barOpacity = opacity;
            if (highlightActive) {
                barOpacity = opacity * 0.22;
            }
            else if (dimmed) {
                barOpacity = opacity * 0.25;
            }
            const rect = el("rect", {
                x: x,
                y: y,
                width: w,
                height: h,
                rx: Math.min(s.barRadius, w / 2, h / 2),
                fill: barColor,
                "fill-opacity": barOpacity,
                stroke: s.barBorder ? s.barBorderColor : "none",
                "stroke-width": s.barBorder ? 1 : 0
            }, barsGroup);
            this.barNodes.push(rect);
            if (highlightActive) {
                const hCount = model.highlightBins[i] || 0;
                if (hCount > 0) {
                    const hy = sy(hCount);
                    el("rect", {
                        x: x,
                        y: hy,
                        width: w,
                        height: Math.max(0, baseY - hy),
                        rx: Math.min(s.barRadius, w / 2, Math.max(0, baseY - hy) / 2),
                        fill: barColor,
                        "fill-opacity": opacity,
                        stroke: s.barBorder ? s.barBorderColor : "none",
                        "stroke-width": s.barBorder ? 1 : 0,
                        "pointer-events": "none"
                    }, overlayGroup);
                }
            }
        }
        /* ---------- KDE 曲线 ---------- */
        if (s.kdeShow && model.kde.length > 1) {
            const g = el("g", { class: "ih-kde", "pointer-events": "none" }, root);
            let d = "";
            for (let i = 0; i < model.kde.length; i++) {
                const p = model.kde[i];
                d += (i === 0 ? "M" : "L") + sx(p.x).toFixed(2) + " " + sy(Math.min(p.y, yMax)).toFixed(2);
            }
            if (s.kdeShowArea) {
                const areaD = d
                    + `L${sx(model.kde[model.kde.length - 1].x).toFixed(2)} ${baseY.toFixed(2)}`
                    + `L${sx(model.kde[0].x).toFixed(2)} ${baseY.toFixed(2)}Z`;
                el("path", {
                    d: areaD,
                    fill: s.kdeColor,
                    "fill-opacity": 1 - clamp(s.kdeAreaTransparency, 0, 100) / 100,
                    stroke: "none"
                }, g);
            }
            el("path", {
                d: d,
                fill: "none",
                stroke: s.kdeColor,
                "stroke-width": s.kdeWidth,
                "stroke-dasharray": dashArray(s.kdeStyle, s.kdeWidth),
                "stroke-linejoin": "round",
                "stroke-linecap": "round"
            }, g);
        }
        /* ---------- 坐标轴 ---------- */
        this.renderAxes(root, plot, model, sx, yTickValues, yLabels, yMax);
        /* ---------- 统计量图例（先算好位置，供常量线标签避让） ---------- */
        const statsLayout = s.statsShow ? this.layoutStatsPanel(plot, model) : null;
        /* ---------- 常量线 ---------- */
        this.renderConstantLines(root, plot, model, sx, statsLayout ? statsLayout.rect : null);
        /* ---------- 统计量图例 ---------- */
        if (statsLayout) {
            this.drawStatsPanel(root, statsLayout, plot);
        }
    }
    renderEmpty(width, height, message) {
        if (!message) {
            return;
        }
        const g = el("g", { class: "ih-empty" }, this.svg);
        const lines = this.wrapText(message, Math.max(80, width - 40), 12);
        const lineHeight = 18;
        const totalHeight = lines.length * lineHeight;
        const startY = Math.max(20, height / 2 - totalHeight / 2 + 12);
        for (let i = 0; i < lines.length; i++) {
            el("text", {
                x: width / 2,
                y: startY + i * lineHeight,
                "text-anchor": "middle",
                fill: "#8A8886",
                "font-size": 12,
                "font-family": "'Segoe UI', 'Microsoft YaHei', sans-serif"
            }, g).textContent = lines[i];
        }
    }
    wrapText(text, maxWidth, fontSize) {
        const result = [];
        let current = "";
        for (const ch of text) {
            const next = current + ch;
            if (estimateTextWidth(next, fontSize) > maxWidth && current.length) {
                result.push(current);
                current = ch;
            }
            else {
                current = next;
            }
        }
        if (current) {
            result.push(current);
        }
        return result.length ? result : [text];
    }
    renderAxes(root, plot, model, sx, yTickValues, yLabels, yMax) {
        const s = this.settings;
        const g = el("g", { class: "ih-axis" }, root);
        const font = `'Segoe UI', 'Microsoft YaHei', sans-serif`;
        // X 轴刻度
        if (s.showXAxis) {
            const tickCount = clamp(Math.round(plot.width / 78), 2, 10);
            const xTicks = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .ticks */ .Zc)(model.domainMin, model.domainMax, tickCount);
            const xStep = (0,_stats__WEBPACK_IMPORTED_MODULE_2__/* .tickStep */ .sG)(model.domainMin, model.domainMax, tickCount);
            el("line", {
                x1: plot.x, x2: plot.x + plot.width,
                y1: plot.y + plot.height, y2: plot.y + plot.height,
                stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
            }, g);
            for (const t of xTicks) {
                if (t < model.domainMin - 1e-9 || t > model.domainMax + 1e-9) {
                    continue;
                }
                const x = sx(t);
                el("line", {
                    x1: x, x2: x,
                    y1: plot.y + plot.height, y2: plot.y + plot.height + 4,
                    stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
                }, g);
                const label = formatTickValue(t, xStep);
                const textAttrs = {
                    x: x,
                    y: plot.y + plot.height + (s.labelAngle === 0 ? 14 : 10),
                    fill: s.labelColor,
                    "font-size": s.axisFontSize,
                    "font-family": font
                };
                if (s.labelAngle === 0) {
                    textAttrs["text-anchor"] = "middle";
                }
                else {
                    textAttrs["text-anchor"] = "end";
                    textAttrs["transform"] = `rotate(${-s.labelAngle}, ${x}, ${plot.y + plot.height + 10})`;
                }
                el("text", textAttrs, g).textContent = label;
            }
            if (s.showXTitle && s.xTitle) {
                const titleY = s.showXAxis
                    ? plot.y + plot.height + (s.labelAngle === 0 ? 14 : 10) + xAxisTitleOffset(s) + s.titleFontSize
                    : plot.y + plot.height + s.titleFontSize + 6;
                el("text", {
                    x: plot.x + plot.width / 2,
                    y: titleY,
                    "text-anchor": "middle",
                    fill: s.labelColor,
                    "font-size": s.titleFontSize,
                    "font-family": font
                }, g).textContent = s.xTitle;
            }
        }
        // Y 轴刻度
        if (s.showYAxis) {
            el("line", {
                x1: plot.x, x2: plot.x,
                y1: plot.y, y2: plot.y + plot.height,
                stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
            }, g);
            const yMinValue = yTickValues[0];
            const ySpan = (yMax - yMinValue) || 1;
            for (let i = 0; i < yTickValues.length; i++) {
                const v = yTickValues[i];
                const yy = plot.y + plot.height - ((v - yMinValue) / ySpan) * plot.height;
                el("line", {
                    x1: plot.x - 4, x2: plot.x,
                    y1: yy, y2: yy,
                    stroke: s.axisColor, "stroke-width": 1, "shape-rendering": "crispEdges"
                }, g);
                el("text", {
                    x: plot.x - 7,
                    y: yy + s.axisFontSize * 0.35,
                    "text-anchor": "end",
                    fill: s.labelColor,
                    "font-size": s.axisFontSize,
                    "font-family": font
                }, g).textContent = yLabels[i];
            }
            if (s.showYTitle && s.yTitle) {
                const titleX = 8 + s.titleFontSize * 0.5;
                el("text", {
                    x: 0,
                    y: 0,
                    transform: `translate(${titleX}, ${plot.y + plot.height / 2}) rotate(-90)`,
                    "text-anchor": "middle",
                    fill: s.labelColor,
                    "font-size": s.titleFontSize,
                    "font-family": font
                }, g).textContent = s.yTitle;
            }
        }
    }
    renderConstantLines(root, plot, model, sx, blocked) {
        const s = this.settings;
        const stats = model.stats;
        const items = [];
        for (const def of _settings__WEBPACK_IMPORTED_MODULE_0__/* .LINE_DEFINITIONS */ .yJ) {
            const ls = s.lines[def.key];
            if (!ls || !ls.show) {
                continue;
            }
            const value = def.value(stats);
            if (!isFinite(value)) {
                continue;
            }
            if (value < model.domainMin || value > model.domainMax) {
                continue;
            }
            items.push({ definition: def, settings: ls, value: value, x: sx(value) });
        }
        if (!items.length) {
            return;
        }
        const g = el("g", { class: "ih-lines", "pointer-events": "none" }, root);
        // 先画线
        for (const item of items) {
            el("line", {
                x1: item.x, x2: item.x,
                y1: plot.y, y2: plot.y + plot.height,
                stroke: item.settings.color,
                "stroke-width": item.settings.width,
                "stroke-dasharray": dashArray(item.settings.style, item.settings.width),
                "stroke-linecap": "butt"
            }, g);
        }
        // 再画标签（自动分道避让）
        const labels = items.filter(i => i.settings.showLabel);
        if (!labels.length) {
            return;
        }
        const ordered = labels.slice().sort((a, b) => a.x - b.x);
        const font = `'Segoe UI', 'Microsoft YaHei', sans-serif`;
        const fontSize = Math.max(9, Math.min(12, s.axisFontSize));
        const laneHeight = fontSize + 6;
        const laneRight = [];
        const laneLimit = Math.max(1, Math.floor((plot.height * 0.55) / laneHeight));
        ordered.forEach(item => {
            const text = `${item.definition.label} ${formatNumber(item.value, this.autoDecimals(model, 2))}`;
            const w = estimateTextWidth(text, fontSize) + 10;
            const h = fontSize + 5;
            let left = item.x - w / 2;
            left = clamp(left, plot.x + 1, plot.x + plot.width - w - 1);
            let lane = 0;
            while (lane < laneLimit) {
                const candidateTop = plot.y + 3 + lane * laneHeight;
                const hitsPrevious = laneRight[lane] !== undefined && left < laneRight[lane] + 4;
                const hitsBlocked = blocked
                    ? this.rectsIntersect(left, candidateTop, w, h, blocked)
                    : false;
                if (!hitsPrevious && !hitsBlocked) {
                    break;
                }
                lane++;
            }
            if (lane >= laneLimit) {
                return;
            }
            laneRight[lane] = left + w;
            const top = plot.y + 3 + lane * laneHeight;
            el("rect", {
                x: left, y: top, width: w, height: h,
                rx: 2, ry: 2,
                fill: "#FFFFFF", "fill-opacity": 0.82,
                stroke: item.settings.color, "stroke-opacity": 0.35, "stroke-width": 0.8
            }, g);
            el("text", {
                x: left + w / 2,
                y: top + h / 2 + fontSize * 0.36,
                "text-anchor": "middle",
                fill: item.settings.color,
                "font-size": fontSize,
                "font-weight": 600,
                "font-family": font
            }, g).textContent = text;
        });
    }
    /** 根据数据量级给出合理的小数位 */
    autoDecimals(model, maxDecimals) {
        const span = Math.abs(model.domainMax - model.domainMin);
        if (!isFinite(span) || span === 0) {
            return Math.min(2, maxDecimals);
        }
        if (span >= 1000) {
            return 0;
        }
        if (span >= 100) {
            return 1;
        }
        return Math.min(maxDecimals, 2);
    }
    rectsIntersect(ax, ay, aw, ah, b) {
        return !(ax + aw < b.x || ax > b.x + b.width || ay + ah < b.y || ay > b.y + b.height);
    }
    /** 计算统计量图例的尺寸与位置（不绘制） */
    layoutStatsPanel(plot, model) {
        const s = this.settings;
        const stats = model.stats;
        const decimals = s.statsDecimals;
        const items = [];
        for (const def of _settings__WEBPACK_IMPORTED_MODULE_0__/* .STAT_LABELS */ .Zh) {
            if (!s.statsVisible[def.key]) {
                continue;
            }
            const raw = stats[def.key];
            let text;
            if (def.key === "count") {
                text = String(Math.round(raw));
            }
            else if (!isFinite(raw)) {
                text = "—";
            }
            else {
                text = formatNumber(raw, decimals);
            }
            items.push({ label: def.label, value: text });
        }
        if (!items.length) {
            return null;
        }
        const fontSize = s.statsFontSize;
        const cols = Math.max(1, Math.min(s.statsColumns, items.length, 3));
        const rows = Math.ceil(items.length / cols);
        const lineHeight = fontSize * 1.6;
        const paddingX = 9;
        const paddingY = 7;
        const colGap = 14;
        const colWidths = [];
        for (let c = 0; c < cols; c++) {
            colWidths.push(0);
        }
        items.forEach((item, i) => {
            const c = i % cols;
            const w = estimateTextWidth(item.label, fontSize) + 8 + estimateTextWidth(item.value, fontSize);
            if (w > colWidths[c]) {
                colWidths[c] = w;
            }
        });
        let contentWidth = 0;
        for (let c = 0; c < cols; c++) {
            contentWidth += colWidths[c] + (c > 0 ? colGap : 0);
        }
        const panelW = contentWidth + paddingX * 2;
        const panelH = rows * lineHeight + paddingY * 2;
        const inset = 12;
        const position = s.statsPosition;
        const isRight = position === "topRight" || position === "bottomRight";
        const isBottom = position === "bottomLeft" || position === "bottomRight";
        let panelX = isRight ? plot.x + plot.width - panelW - inset : plot.x + inset;
        let panelY = isBottom ? plot.y + plot.height - panelH - inset : plot.y + inset;
        panelX = Math.max(plot.x + 2, Math.min(panelX, plot.x + plot.width - panelW - 2));
        panelY = Math.max(plot.y + 2, Math.min(panelY, plot.y + plot.height - panelH - 2));
        return {
            rect: { x: panelX, y: panelY, width: panelW, height: panelH },
            items: items,
            colWidths: colWidths,
            cols: cols,
            lineHeight: lineHeight,
            paddingX: paddingX,
            paddingY: paddingY,
            colGap: colGap,
            fontSize: fontSize
        };
    }
    drawStatsPanel(root, layout, plot) {
        const s = this.settings;
        const rect = layout.rect;
        const g = el("g", { class: "ih-stats", "pointer-events": "none" }, root);
        el("rect", {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
            rx: 4,
            ry: 4,
            fill: s.statsBackground,
            "fill-opacity": 1 - clamp(s.statsTransparency, 0, 100) / 100,
            stroke: s.statsShowBorder ? s.statsBorderColor : "none",
            "stroke-width": s.statsShowBorder ? 1 : 0
        }, g);
        const font = `'Segoe UI', 'Microsoft YaHei', sans-serif`;
        layout.items.forEach((item, i) => {
            const c = i % layout.cols;
            const r = Math.floor(i / layout.cols);
            let colX = rect.x + layout.paddingX;
            for (let k = 0; k < c; k++) {
                colX += layout.colWidths[k] + layout.colGap;
            }
            const y = rect.y + layout.paddingY + r * layout.lineHeight + layout.fontSize * 1.02;
            el("text", {
                x: colX,
                y: y,
                fill: s.statsFontColor,
                "fill-opacity": 0.72,
                "font-size": layout.fontSize,
                "font-family": font
            }, g).textContent = item.label;
            el("text", {
                x: colX + layout.colWidths[c],
                y: y,
                "text-anchor": "end",
                fill: s.statsFontColor,
                "font-size": layout.fontSize,
                "font-weight": 600,
                "font-family": font
            }, g).textContent = item.value;
        });
    }
    /* --------------------------- 交互 --------------------------- */
    eventPoint(e) {
        const rect = this.svg.getBoundingClientRect();
        return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }
    binIndexAt(x) {
        const model = this.model;
        if (!model || !model.bins.length || !(this.plot.width > 0)) {
            return -1;
        }
        if (x < this.plot.x || x > this.plot.x + this.plot.width) {
            return -1;
        }
        const ratio = (x - this.plot.x) / this.plot.width;
        const idx = Math.floor(ratio * model.bins.length);
        return clamp(idx, 0, model.bins.length - 1);
    }
    buildSelectionIds(binIndex) {
        const model = this.model;
        if (!model || !model.categoryColumn) {
            return [];
        }
        const ids = [];
        const bin = model.bins[binIndex];
        for (const rowIndex of bin.indices) {
            const row = model.rowIndices[rowIndex];
            ids.push(this.host.createSelectionIdBuilder()
                .withCategory(model.categoryColumn, row)
                .createSelectionId());
        }
        return ids;
    }
    handleClick(e) {
        const model = this.model;
        if (!model || !model.bins.length) {
            return;
        }
        const point = this.eventPoint(e);
        const idx = this.binIndexAt(point.x);
        if (idx < 0) {
            this.selectedBins = [];
            this.selectionManager.clear();
            this.render();
            return;
        }
        const ids = this.buildSelectionIds(idx);
        if (!ids.length) {
            return;
        }
        const multi = e.ctrlKey || e.metaKey || e.shiftKey;
        let next;
        if (multi) {
            next = this.selectedBins.indexOf(idx) >= 0
                ? this.selectedBins.filter(i => i !== idx)
                : this.selectedBins.concat([idx]);
        }
        else {
            next = this.selectedBins.length === 1 && this.selectedBins[0] === idx ? [] : [idx];
        }
        const allIds = [];
        for (const i of next) {
            allIds.push(...this.buildSelectionIds(i));
        }
        this.selectedBins = next;
        if (!allIds.length) {
            this.selectionManager.clear();
            this.render();
            return;
        }
        this.selectionManager.select(allIds, multi).then(() => {
            this.render();
        }, () => {
            this.render();
        });
    }
    handleMouseMove(e) {
        const model = this.model;
        if (!model || !model.bins.length) {
            return;
        }
        const point = this.eventPoint(e);
        const idx = this.binIndexAt(point.x);
        if (idx < 0) {
            this.hideTooltip();
            this.setHoverBin(-1);
            return;
        }
        this.setHoverBin(idx);
        const bin = model.bins[idx];
        const total = model.stats.count;
        const share = total ? (bin.count / total) * 100 : 0;
        const dec = this.autoDecimals(model, 2);
        const dataItems = [
            { displayName: "区间", value: `${formatNumber(bin.x0, dec)} ~ ${formatNumber(bin.x1, dec)}` },
            { displayName: "计数", value: String(bin.count) },
            { displayName: "占比", value: `${share.toFixed(1)}%` }
        ];
        this.tooltipService.show({
            coordinates: [point.x, point.y],
            isTouchEvent: false,
            dataItems: dataItems,
            identities: this.buildSelectionIds(idx)
        });
    }
    setHoverBin(idx) {
        if (this.hoverBin === idx) {
            return;
        }
        if (this.hoverBin >= 0 && this.barNodes[this.hoverBin]) {
            this.barNodes[this.hoverBin].setAttribute("stroke", this.settings.barBorder ? this.settings.barBorderColor : "none");
            this.barNodes[this.hoverBin].setAttribute("stroke-width", this.settings.barBorder ? "1" : "0");
        }
        this.hoverBin = idx;
        if (idx >= 0 && this.barNodes[idx]) {
            this.barNodes[idx].setAttribute("stroke", "#605E5C");
            this.barNodes[idx].setAttribute("stroke-width", "1");
        }
    }
    handleMouseLeave() {
        this.hideTooltip();
        this.setHoverBin(-1);
    }
    hideTooltip() {
        try {
            this.tooltipService.hide({ immediately: true, isTouchEvent: false });
        }
        catch (e) {
            // ignore
        }
    }
    /* --------------------------- 属性面板 --------------------------- */
    /** 新版格式面板 */
    getFormattingModel() {
        return (0,_formatting__WEBPACK_IMPORTED_MODULE_1__/* .buildFormattingModel */ .P)(this.settings, this.themeColor);
    }
    /** 旧版格式面板（兼容较老的 Power BI Desktop） */
    enumerateObjectInstances(options) {
        const s = this.settings;
        const instances = [];
        const push = (objectName, displayName, properties) => {
            instances.push({ objectName: objectName, displayName: displayName, selector: null, properties: properties });
        };
        switch (options.objectName) {
            case "bins":
                push("bins", "数据分箱", {
                    binCount: s.binCount
                });
                break;
            case "bars":
                push("bars", "柱形", {
                    fillColor: toPowerBiColor(s.barFillSet ? s.barFill : this.themeColor),
                    transparency: s.barTransparency,
                    gap: s.barGap,
                    cornerRadius: s.barRadius,
                    showBorder: s.barBorder,
                    borderColor: toPowerBiColor(s.barBorderColor)
                });
                break;
            case "kde":
                push("kde", "KDE 密度曲线", {
                    show: s.kdeShow,
                    lineColor: toPowerBiColor(s.kdeColor),
                    lineWidth: s.kdeWidth,
                    lineStyle: s.kdeStyle,
                    bandwidth: s.kdeBandwidth,
                    showArea: s.kdeShowArea,
                    areaTransparency: s.kdeAreaTransparency
                });
                break;
            case "axes":
                push("axes", "坐标轴与标签", {
                    showXAxis: s.showXAxis,
                    showYAxis: s.showYAxis,
                    showXTitle: s.showXTitle,
                    xTitle: s.xTitle,
                    showYTitle: s.showYTitle,
                    yTitle: s.yTitle,
                    labelAngle: String(s.labelAngle),
                    axisFontSize: s.axisFontSize,
                    titleFontSize: s.titleFontSize,
                    axisColor: toPowerBiColor(s.axisColor),
                    labelColor: toPowerBiColor(s.labelColor),
                    showGridlines: s.showGridlines,
                    gridlineColor: toPowerBiColor(s.gridlineColor),
                    yFromZero: s.yFromZero
                });
                break;
            case "stats":
                push("stats", "统计量图例", {
                    show: s.statsShow,
                    position: s.statsPosition,
                    columns: s.statsColumns,
                    fontSize: s.statsFontSize,
                    fontColor: toPowerBiColor(s.statsFontColor),
                    backgroundColor: toPowerBiColor(s.statsBackground),
                    transparency: s.statsTransparency,
                    showBorder: s.statsShowBorder,
                    borderColor: toPowerBiColor(s.statsBorderColor),
                    decimals: s.statsDecimals,
                    mean: s.statsVisible.mean,
                    median: s.statsVisible.median,
                    std: s.statsVisible.std,
                    variance: s.statsVisible.variance,
                    count: s.statsVisible.count,
                    max: s.statsVisible.max,
                    min: s.statsVisible.min,
                    cv: s.statsVisible.cv,
                    vsf: s.statsVisible.vsf,
                    skewness: s.statsVisible.skewness,
                    kurtosis: s.statsVisible.kurtosis,
                    p25: s.statsVisible.p25,
                    p75: s.statsVisible.p75,
                    p90: s.statsVisible.p90,
                    p10: s.statsVisible.p10
                });
                break;
            default: {
                for (const def of _settings__WEBPACK_IMPORTED_MODULE_0__/* .LINE_DEFINITIONS */ .yJ) {
                    if (def.objectName !== options.objectName) {
                        continue;
                    }
                    const ls = s.lines[def.key];
                    push(def.objectName, "常量线 · " + def.label, {
                        show: ls.show,
                        lineColor: toPowerBiColor(ls.color),
                        lineWidth: ls.width,
                        lineStyle: ls.style,
                        showLabel: ls.showLabel
                    });
                }
                break;
            }
        }
        return instances;
    }
}
function xAxisTitleOffset(s) {
    if (s.labelAngle === 0) {
        return 4;
    }
    return s.axisFontSize * 1.1;
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		if(Array.isArray(definition)) {
/******/ 			var i = 0;
/******/ 			while(i < definition.length) {
/******/ 				var key = definition[i++];
/******/ 				var binding = definition[i++];
/******/ 				var descriptor = binding === 0 ? { enumerable: true, value: definition[i++] } : { enumerable: true, get: binding };
/******/ 				if(!__webpack_require__.o(exports, key)) Object.defineProperty(exports, key, descriptor);
/******/ 			}
/******/ 		} else {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
let __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it declares 'intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40' on top-level, which conflicts with the current library output.
(() => {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _src_visual__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(848);

var powerbiKey = "powerbi";
var powerbi = window[powerbiKey];
var intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40 = {
    name: 'intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40',
    displayName: '区间直方图 Interval Histogram',
    class: 'Visual',
    apiVersion: '5.9.0',
    create: (options) => {
        if (_src_visual__WEBPACK_IMPORTED_MODULE_0__/* .Visual */ .b) {
            return new _src_visual__WEBPACK_IMPORTED_MODULE_0__/* .Visual */ .b(options);
        }
        throw 'Visual instance not found';
    },
    createModalDialog: (dialogId, options, initialState) => {
        const dialogRegistry = globalThis.dialogRegistry;
        if (dialogId in dialogRegistry) {
            new dialogRegistry[dialogId](options, initialState);
        }
    },
    custom: true
};
if (typeof powerbi !== "undefined") {
    powerbi.visuals = powerbi.visuals || {};
    powerbi.visuals.plugins = powerbi.visuals.plugins || {};
    powerbi.visuals.plugins["intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40"] = intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40;
}
/* harmony default export */ const visualPlugin = (intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40);

/* harmony export */ __webpack_require__.d(__webpack_exports__, [
/* harmony export */   "default", 0, visualPlugin
/* harmony export */ ]);

})();

intervalHistogram4B7E1C2D9A5F4E8B8C3D6A1F2E9B7C40 = __webpack_exports__;
/******/ })()
;