/**
 * 生成 assets/icon.png（40x40，RGBA），无需外部依赖。
 * 用法：node tools/make-icon.js
 */
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const SIZE = 80;      // 超采样尺寸
const OUT = 40;       // 最终尺寸

const pixels = new Uint8Array(SIZE * SIZE * 4); // 全透明

function px(x, y, r, g, b, a) {
    if (x < 0 || y < 0 || x >= SIZE || y >= SIZE) {
        return;
    }
    const i = (y * SIZE + x) * 4;
    const sa = a / 255;
    const da = pixels[i + 3] / 255;
    const oa = sa + da * (1 - sa);
    if (oa <= 0) {
        return;
    }
    pixels[i] = Math.round((r * sa + pixels[i] * da * (1 - sa)) / oa);
    pixels[i + 1] = Math.round((g * sa + pixels[i + 1] * da * (1 - sa)) / oa);
    pixels[i + 2] = Math.round((b * sa + pixels[i + 2] * da * (1 - sa)) / oa);
    pixels[i + 3] = Math.round(oa * 255);
}

function rect(x0, y0, w, h, color) {
    for (let y = y0; y < y0 + h; y++) {
        for (let x = x0; x < x0 + w; x++) {
            px(x, y, color[0], color[1], color[2], color[3]);
        }
    }
}

function roundRectTop(x0, y0, w, h, radius, color) {
    for (let y = y0; y < y0 + h; y++) {
        for (let x = x0; x < x0 + w; x++) {
            let inside = true;
            const rr = Math.min(radius, w / 2, h / 2);
            if (y < y0 + rr) {
                for (const cx of [x0 + rr, x0 + w - rr]) {
                    if (x < cx) {
                        const dx = x - cx;
                        const dy = y - (y0 + rr);
                        if (dx * dx + dy * dy > rr * rr) {
                            inside = false;
                        }
                        break;
                    }
                }
            }
            if (inside) {
                px(x, y, color[0], color[1], color[2], color[3]);
            }
        }
    }
}

const BLUE = [44, 123, 229, 255];
const RED = [192, 57, 43, 255];
const GRAY = [154, 160, 166, 255];

const baseline = 70;
const heights = [18, 30, 46, 58, 40, 26, 14];
const barW = 8;
const gap = 2;
const totalW = heights.length * barW + (heights.length - 1) * gap;
const startX = Math.round((SIZE - totalW) / 2);

heights.forEach((h, i) => {
    const x = startX + i * (barW + gap);
    roundRectTop(x, baseline - h, barW, h, 2, BLUE);
});

// 基线
rect(4, baseline, SIZE - 8, 2, GRAY);

// 均值虚线
for (let y = 6; y < baseline + 4; y++) {
    if (Math.floor((y - 6) / 3) % 2 === 0) {
        rect(Math.round(SIZE / 2) - 1, y, 3, 3, RED);
    }
}

// 降采样到 40x40
const out = Buffer.alloc(OUT * OUT * 4);
const scale = SIZE / OUT;
for (let y = 0; y < OUT; y++) {
    for (let x = 0; x < OUT; x++) {
        let r = 0, g = 0, b = 0, a = 0;
        for (let dy = 0; dy < scale; dy++) {
            for (let dx = 0; dx < scale; dx++) {
                const i = ((y * scale + dy) * SIZE + (x * scale + dx)) * 4;
                const aa = pixels[i + 3] / 255;
                r += pixels[i] * aa;
                g += pixels[i + 1] * aa;
                b += pixels[i + 2] * aa;
                a += aa;
            }
        }
        const n = scale * scale;
        const o = (y * OUT + x) * 4;
        out[o] = a > 0 ? Math.round(r / a) : 0;
        out[o + 1] = a > 0 ? Math.round(g / a) : 0;
        out[o + 2] = a > 0 ? Math.round(b / a) : 0;
        out[o + 3] = Math.round((a / n) * 255);
    }
}

// --- PNG 编码 ---
const CRC_TABLE = (() => {
    const table = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) {
            c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
        }
        table[n] = c;
    }
    return table;
})();

function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
        c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, "ascii");
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
    return Buffer.concat([len, typeBuf, data, crc]);
}

const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(OUT, 0);
ihdr.writeUInt32BE(OUT, 4);
ihdr[8] = 8;   // bit depth
ihdr[9] = 6;   // RGBA
ihdr[10] = 0;
ihdr[11] = 0;
ihdr[12] = 0;

const raw = Buffer.alloc(OUT * (OUT * 4 + 1));
for (let y = 0; y < OUT; y++) {
    raw[y * (OUT * 4 + 1)] = 0;
    out.copy(raw, y * (OUT * 4 + 1) + 1, y * OUT * 4, (y + 1) * OUT * 4);
}

const png = Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", zlib.deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0))
]);

const target = path.join(__dirname, "..", "assets", "icon.png");
fs.mkdirSync(path.dirname(target), { recursive: true });
fs.writeFileSync(target, png);
console.log("icon written:", target, png.length, "bytes");
