"use strict";

import powerbi from "powerbi-visuals-api";
import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";

import FormattingSettingsCard = formattingSettings.SimpleCard;
import FormattingSettingsSlice = formattingSettings.Slice;
import FormattingSettingsModel = formattingSettings.Model;

/**
 * 数值范围校验器。ValidatorType.Min = 0 / Max = 1，
 * 这里直接写数值，避免依赖 const enum 在不同打包器下的内联行为。
 */
function range(min: number, max: number): powerbi.visuals.NumUpDownFormat {
    return {
        minValue: { type: 0, value: min },
        maxValue: { type: 1, value: max }
    } as any;
}

/** 线型枚举，必须与 capabilities.json 中的 enumeration 值保持一致 */
export const LINE_DASH_ITEMS: powerbi.IEnumMember[] = [
    { value: "solid", displayName: "实线" },
    { value: "dashed", displayName: "虚线" },
    { value: "dotted", displayName: "点线" },
    { value: "dashDot", displayName: "点划线" }
];

export const ROTATION_ITEMS: powerbi.IEnumMember[] = [
    { value: "auto", displayName: "自动" },
    { value: "0", displayName: "0°" },
    { value: "45", displayName: "45°" },
    { value: "90", displayName: "90°" }
];

export const NEGATIVE_ITEMS: powerbi.IEnumMember[] = [
    { value: "ignore", displayName: "忽略（不计入合计，不显示）" },
    { value: "absolute", displayName: "取绝对值计入" },
    { value: "zero", displayName: "按 0 计入" }
];

export const BLANK_ITEMS: powerbi.IEnumMember[] = [
    { value: "ignore", displayName: "忽略（不显示）" },
    { value: "zero", displayName: "按 0 计入" }
];

/** 柱状图设置 */
class BarCardSettings extends FormattingSettingsCard {
    fill = new formattingSettings.ColorPicker({
        name: "fill",
        displayName: "柱形颜色",
        value: { value: "#3B6FE0" }
    });

    transparency = new formattingSettings.Slider({
        name: "transparency",
        displayName: "透明度",
        description: "0% 为完全不透明，100% 为完全透明。",
        value: 0,
        options: range(0, 100)
    });

    borderRadius = new formattingSettings.NumUpDown({
        name: "borderRadius",
        displayName: "圆角",
        value: 2,
        options: range(0, 12)
    });

    innerPadding = new formattingSettings.NumUpDown({
        name: "innerPadding",
        displayName: "柱间距",
        description: "0 表示柱子紧贴，0.9 表示柱子极细。",
        value: 0.35,
        options: range(0, 0.9)
    });

    showValues = new formattingSettings.ToggleSwitch({
        name: "showValues",
        displayName: "显示数值标签",
        value: false
    });

    valueFontSize = new formattingSettings.NumUpDown({
        name: "valueFontSize",
        displayName: "数值标签字号",
        value: 10,
        options: range(6, 24)
    });

    valueColor = new formattingSettings.ColorPicker({
        name: "valueColor",
        displayName: "数值标签颜色",
        value: { value: "#323130" }
    });

    name: string = "bar";
    displayName: string = "柱状图";
    slices: Array<FormattingSettingsSlice> = [
        this.fill,
        this.transparency,
        this.borderRadius,
        this.innerPadding,
        this.showValues,
        this.valueFontSize,
        this.valueColor
    ];
}

/** 累计折线设置 */
class LineCardSettings extends FormattingSettingsCard {
    fill = new formattingSettings.ColorPicker({
        name: "fill",
        displayName: "折线颜色",
        value: { value: "#ED7D31" }
    });

    transparency = new formattingSettings.Slider({
        name: "transparency",
        displayName: "透明度",
        value: 0,
        options: range(0, 100)
    });

    width = new formattingSettings.Slider({
        name: "width",
        displayName: "粗细",
        value: 2,
        options: range(0.5, 8)
    });

    dashType = new formattingSettings.ItemDropdown({
        name: "dashType",
        displayName: "线型",
        items: LINE_DASH_ITEMS,
        value: LINE_DASH_ITEMS[0]
    });

    smooth = new formattingSettings.ToggleSwitch({
        name: "smooth",
        displayName: "平滑曲线",
        description: "开启后使用单调三次插值，曲线不会越过相邻数据点。",
        value: false
    });

    showMarkers = new formattingSettings.ToggleSwitch({
        name: "showMarkers",
        displayName: "显示标记",
        value: true
    });

    markerSize = new formattingSettings.Slider({
        name: "markerSize",
        displayName: "标记大小",
        value: 6,
        options: range(2, 16)
    });

    name: string = "line";
    displayName: string = "累计折线";
    slices: Array<FormattingSettingsSlice> = [
        this.fill,
        this.transparency,
        this.width,
        this.dashType,
        this.smooth,
        this.showMarkers,
        this.markerSize
    ];
}

/** 参考线设置 */
class ReferenceLineCardSettings extends FormattingSettingsCard {
    show = new formattingSettings.ToggleSwitch({
        name: "show",
        displayName: "显示参考线",
        value: true
    });

    percent = new formattingSettings.Slider({
        name: "percent",
        displayName: "参考值 (%)",
        description: "默认 80%，即帕累托法则中的“80% 累计占比”阈值。",
        value: 80,
        options: range(0, 100)
    });

    fill = new formattingSettings.ColorPicker({
        name: "fill",
        displayName: "参考线颜色",
        value: { value: "#C00000" }
    });

    transparency = new formattingSettings.Slider({
        name: "transparency",
        displayName: "透明度",
        value: 0,
        options: range(0, 100)
    });

    width = new formattingSettings.Slider({
        name: "width",
        displayName: "粗细",
        value: 1.5,
        options: range(0.5, 8)
    });

    dashType = new formattingSettings.ItemDropdown({
        name: "dashType",
        displayName: "线型",
        items: LINE_DASH_ITEMS,
        value: LINE_DASH_ITEMS[1]
    });

    showMarkers = new formattingSettings.ToggleSwitch({
        name: "showMarkers",
        displayName: "显示交叉标记",
        description: "在累计折线与参考线的交点处绘制实心圆点。",
        value: true
    });

    showLabel = new formattingSettings.ToggleSwitch({
        name: "showLabel",
        displayName: "显示参考值标签",
        value: true
    });

    name: string = "referenceLine";
    displayName: string = "参考线";
    slices: Array<FormattingSettingsSlice> = [
        this.show,
        this.percent,
        this.fill,
        this.transparency,
        this.width,
        this.dashType,
        this.showMarkers,
        this.showLabel
    ];
}

/** 坐标轴标题设置 */
class AxisTitleCardSettings extends FormattingSettingsCard {
    showXTitle = new formattingSettings.ToggleSwitch({
        name: "showXTitle",
        displayName: "显示 X 轴标题",
        value: false
    });

    xTitle = new formattingSettings.TextInput({
        name: "xTitle",
        displayName: "X 轴标题",
        placeholder: "例如：产品类别",
        value: ""
    });

    showYTitle = new formattingSettings.ToggleSwitch({
        name: "showYTitle",
        displayName: "显示 Y 轴标题",
        value: true
    });

    yTitle = new formattingSettings.TextInput({
        name: "yTitle",
        displayName: "Y 轴标题",
        placeholder: "例如：销售额（元）",
        value: "值"
    });

    showY2Title = new formattingSettings.ToggleSwitch({
        name: "showY2Title",
        displayName: "显示辅助 Y 轴标题",
        value: true
    });

    y2Title = new formattingSettings.TextInput({
        name: "y2Title",
        displayName: "辅助 Y 轴标题",
        placeholder: "例如：累计占比",
        value: "累计占比"
    });

    titleFontSize = new formattingSettings.NumUpDown({
        name: "titleFontSize",
        displayName: "标题字号",
        value: 12,
        options: range(6, 28)
    });

    titleColor = new formattingSettings.ColorPicker({
        name: "titleColor",
        displayName: "标题颜色",
        value: { value: "#605E5C" }
    });

    titleBold = new formattingSettings.ToggleSwitch({
        name: "titleBold",
        displayName: "标题加粗",
        value: false
    });

    name: string = "axisTitle";
    displayName: string = "坐标轴标题";
    slices: Array<FormattingSettingsSlice> = [
        this.showXTitle,
        this.xTitle,
        this.showYTitle,
        this.yTitle,
        this.showY2Title,
        this.y2Title,
        this.titleFontSize,
        this.titleColor,
        this.titleBold
    ];
}

/** 坐标轴与网格设置 */
class AxisFormatCardSettings extends FormattingSettingsCard {
    labelFontSize = new formattingSettings.NumUpDown({
        name: "labelFontSize",
        displayName: "标签字号",
        value: 10,
        options: range(6, 24)
    });

    labelColor = new formattingSettings.ColorPicker({
        name: "labelColor",
        displayName: "标签颜色",
        value: { value: "#605E5C" }
    });

    xLabelRotation = new formattingSettings.ItemDropdown({
        name: "xLabelRotation",
        displayName: "X 轴标签角度",
        items: ROTATION_ITEMS,
        value: ROTATION_ITEMS[0]
    });

    showGridlines = new formattingSettings.ToggleSwitch({
        name: "showGridlines",
        displayName: "显示网格线",
        value: true
    });

    gridlineColor = new formattingSettings.ColorPicker({
        name: "gridlineColor",
        displayName: "网格线颜色",
        value: { value: "#E1DFDD" }
    });

    gridlineTransparency = new formattingSettings.Slider({
        name: "gridlineTransparency",
        displayName: "网格线透明度",
        value: 30,
        options: range(0, 100)
    });

    showY2Axis = new formattingSettings.ToggleSwitch({
        name: "showY2Axis",
        displayName: "显示辅助 Y 轴",
        description: "辅助 Y 轴固定为 0% - 100%，用于累计占比折线。",
        value: true
    });

    name: string = "axisFormat";
    displayName: string = "坐标轴与网格";
    slices: Array<FormattingSettingsSlice> = [
        this.labelFontSize,
        this.labelColor,
        this.xLabelRotation,
        this.showGridlines,
        this.gridlineColor,
        this.gridlineTransparency,
        this.showY2Axis
    ];
}

/** 数据处理设置 */
class DataHandlingCardSettings extends FormattingSettingsCard {
    negativeHandling = new formattingSettings.ItemDropdown({
        name: "negativeHandling",
        displayName: "负数处理",
        description: "帕累托图基于非负数值，需要明确负数的处理方式。",
        items: NEGATIVE_ITEMS,
        value: NEGATIVE_ITEMS[0]
    });

    blankHandling = new formattingSettings.ItemDropdown({
        name: "blankHandling",
        displayName: "空值处理",
        items: BLANK_ITEMS,
        value: BLANK_ITEMS[0]
    });

    showZeroBars = new formattingSettings.ToggleSwitch({
        name: "showZeroBars",
        displayName: "显示 0 值类别",
        description: "关闭后，值为 0 的类别会被整体移除（不参与排名与合计）。",
        value: true
    });

    showNotice = new formattingSettings.ToggleSwitch({
        name: "showNotice",
        displayName: "显示数据处理提示",
        description: "在右下角显示被忽略或特殊处理的记录数量。",
        value: true
    });

    name: string = "dataHandling";
    displayName: string = "数据处理";
    slices: Array<FormattingSettingsSlice> = [
        this.negativeHandling,
        this.blankHandling,
        this.showZeroBars,
        this.showNotice
    ];
}

export class VisualFormattingSettingsModel extends FormattingSettingsModel {
    bar = new BarCardSettings();
    line = new LineCardSettings();
    referenceLine = new ReferenceLineCardSettings();
    axisTitle = new AxisTitleCardSettings();
    axisFormat = new AxisFormatCardSettings();
    dataHandling = new DataHandlingCardSettings();

    cards = [
        this.bar,
        this.line,
        this.referenceLine,
        this.axisTitle,
        this.axisFormat,
        this.dataHandling
    ];
}
