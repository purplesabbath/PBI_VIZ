"use strict";

import powerbi from "powerbi-visuals-api";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import * as d3 from "d3";
import "./../style/visual.less";

import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisual = powerbi.extensibility.visual.IVisual;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import ISelectionManager = powerbi.extensibility.ISelectionManager;
import ISelectionId = powerbi.extensibility.ISelectionId;
import ITooltipService = powerbi.extensibility.ITooltipService;
import IVisualEventService = powerbi.extensibility.IVisualEventService;

import { VisualFormattingSettingsModel } from "./settings";
import { buildParetoData, ParetoData, ParetoDatum } from "./data";

const SVG_NS = "http://www.w3.org/2000/svg";
const FONT_FAMILY = "'Segoe UI', 'Microsoft YaHei', 'PingFang SC', Arial, sans-serif";
const TEXT_COLOR_FALLBACK = "#605E5C";

let measureContext: CanvasRenderingContext2D | null = null;

function measureText(text: string, fontSize: number, bold: boolean): number {
    if (!text) {
        return 0;
    }
    if (!measureContext) {
        const canvas = document.createElement("canvas");
        measureContext = canvas.getContext("2d");
    }
    if (!measureContext) {
        return text.length * fontSize * 0.62;
    }
    measureContext.font = `${bold ? "600" : "400"} ${fontSize}px ${FONT_FAMILY}`;
    return measureContext.measureText(text).width;
}

function svgEl<K extends keyof SVGElementTagNameMap>(tag: K): SVGElementTagNameMap[K] {
    return document.createElementNS(SVG_NS, tag) as SVGElementTagNameMap[K];
}

function setAttrs(el: Element, attrs: { [key: string]: string | number }): void {
    for (const key in attrs) {
        if (Object.prototype.hasOwnProperty.call(attrs, key)) {
            el.setAttribute(key, String(attrs[key]));
        }
    }
}

function clamp(value: number, min: number, max: number): number {
    if (isNaN(value)) {
        return min;
    }
    return Math.min(max, Math.max(min, value));
}

function dashArray(type: string, width: number): string {
    const w = Math.max(0.5, width);
    switch (type) {
        case "dashed":
            return `${Math.max(4, w * 3)},${Math.max(3, w * 2)}`;
        case "dotted":
            return `${Math.max(1, w)},${Math.max(2, w * 1.6)}`;
        case "dashDot":
            return `${Math.max(6, w * 4)},${Math.max(3, w * 2)},${Math.max(1, w)},${Math.max(3, w * 2)}`;
        default:
            return "none";
    }
}

function formatPercent(ratio: number): string {
    if (!isFinite(ratio)) {
        return "-";
    }
    return `${(ratio * 100).toFixed(1)}%`;
}

export class Visual implements IVisual {
    private host: IVisualHost;
    private events: IVisualEventService;
    private tooltipService: ITooltipService;
    private selectionManager: ISelectionManager;

    private container: HTMLElement;
    private svg: SVGSVGElement;
    private emptyEl: HTMLElement;

    private formattingSettingsService: FormattingSettingsService;
    private settings: VisualFormattingSettingsModel;

    private currentData: ParetoData | null = null;
    private selectionPairs: { el: Element; id: ISelectionId }[] = [];

    constructor(options: VisualConstructorOptions) {
        this.host = options.host;
        this.events = options.host.eventService;
        this.tooltipService = options.host.tooltipService;
        this.selectionManager = options.host.createSelectionManager();
        this.formattingSettingsService = new FormattingSettingsService();
        this.settings = new VisualFormattingSettingsModel();

        this.container = document.createElement("div");
        this.container.className = "pareto-root";

        this.svg = svgEl("svg");
        this.svg.setAttribute("class", "pareto-svg");
        this.container.appendChild(this.svg);

        this.emptyEl = document.createElement("div");
        this.emptyEl.className = "pareto-empty";
        this.emptyEl.style.display = "none";
        this.container.appendChild(this.emptyEl);

        options.element.appendChild(this.container);

        // 点击空白区域清除选择
        this.svg.addEventListener("click", () => {
            if (this.selectionManager.hasSelection()) {
                this.selectionManager.clear();
                this.applySelectionStyles();
            }
        });

        this.svg.addEventListener("mouseleave", () => this.hideTooltip());
    }

    public update(options: VisualUpdateOptions): void {
        this.events.renderingStarted(options);
        try {
            const dataView = options.dataViews && options.dataViews[0];
            if (!dataView) {
                this.clearAll();
                this.showMessage("请添加“类别”与“值”字段");
                return;
            }

            this.settings = this.formattingSettingsService.populateFormattingSettingsModel(
                VisualFormattingSettingsModel,
                dataView
            );

            this.render(options.viewport.width, options.viewport.height, dataView);
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            this.clearAll();
            this.showMessage(`渲染失败：${message}`);
            this.events.renderingFailed(options, message);
        } finally {
            this.events.renderingFinished(options);
        }
    }

    public getFormattingModel(): powerbi.visuals.FormattingModel {
        return this.formattingSettingsService.buildFormattingModel(this.settings);
    }

    // ---------------------------------------------------------------- 渲染主流程

    private render(width: number, height: number, dataView: powerbi.DataView): void {
        this.clearAll();

        const w = Math.max(0, width);
        const h = Math.max(0, height);
        this.svg.setAttribute("width", String(w));
        this.svg.setAttribute("height", String(h));
        this.svg.setAttribute("viewBox", `0 0 ${w} ${h}`);

        const data = buildParetoData(dataView, this.settings, this.host);
        this.currentData = data;

        if (!data || data.rows.length === 0) {
            this.showMessage("没有可显示的数据（请检查空值 / 负数 / 0 值的处理设置）");
            return;
        }
        if (w < 40 || h < 40) {
            return;
        }

        this.drawChart(w, h, data, this.buildNotice(data));
    }

    private drawChart(w: number, h: number, data: ParetoData, notice: { text: string; warning: boolean } | null): void {
        const s = this.settings;
        const rows = data.rows;

        const labelFontSize = clamp(s.axisFormat.labelFontSize.value, 6, 24);
        const labelColor = s.axisFormat.labelColor.value.value || TEXT_COLOR_FALLBACK;
        const titleFontSize = clamp(s.axisTitle.titleFontSize.value, 6, 28);
        const titleColor = s.axisTitle.titleColor.value.value || TEXT_COLOR_FALLBACK;
        const titleWeight = s.axisTitle.titleBold.value ? "600" : "400";

        const xTitleText = (s.axisTitle.xTitle.value || "").trim();
        const yTitleText = (s.axisTitle.yTitle.value || "").trim();
        const y2TitleText = (s.axisTitle.y2Title.value || "").trim();
        const showY2Axis = s.axisFormat.showY2Axis.value;
        const showXTitle = s.axisTitle.showXTitle.value && xTitleText.length > 0;
        const showYTitle = s.axisTitle.showYTitle.value && yTitleText.length > 0;
        const showY2Title = showY2Axis && s.axisTitle.showY2Title.value && y2TitleText.length > 0;

        const root = svgEl("g");
        this.svg.appendChild(root);

        // ---- 左侧 Y 轴刻度（绝对值）
        let maxValue = 0;
        for (const row of rows) {
            if (row.value > maxValue) {
                maxValue = row.value;
            }
        }
        if (maxValue <= 0) {
            maxValue = 1;
        }

        const yScale = d3.scaleLinear().domain([0, maxValue]).nice(5);
        const yTicks = yScale.ticks(5);
        const yTickLabels = yTicks.map((t) => data.formatValue(t));

        let yTickWidth = 0;
        for (const label of yTickLabels) {
            yTickWidth = Math.max(yTickWidth, measureText(label, labelFontSize, false));
        }

        const y2TickLabels = ["0%", "20%", "40%", "60%", "80%", "100%"];
        let y2TickWidth = 0;
        if (showY2Axis) {
            for (const label of y2TickLabels) {
                y2TickWidth = Math.max(y2TickWidth, measureText(label, labelFontSize, false));
            }
        }

        const titleSpace = titleFontSize * 2.2;

        // ---- X 轴标签宽度（抽样，避免数据量过大时逐条测量）
        const sampleSize = Math.min(rows.length, 60);
        let maxXLabelWidth = 0;
        for (let i = 0; i < sampleSize; i++) {
            maxXLabelWidth = Math.max(maxXLabelWidth, measureText(rows[i].label, labelFontSize, false));
        }

        const paddingLeft = yTickWidth + 10 + (showYTitle ? titleSpace : 0);
        const paddingRight = (showY2Axis ? y2TickWidth + 10 : 8) + (showY2Title ? titleSpace : 0);
        const paddingTop = notice ? 19 : 14;

        const bandEstimate = Math.max(1, (w - paddingLeft - paddingRight) / rows.length);
        const rotationSetting = String(s.axisFormat.xLabelRotation.value.value || "auto");
        let angle: number;
        if (rotationSetting === "auto") {
            angle = maxXLabelWidth + 10 > bandEstimate ? 45 : 0;
        } else {
            angle = Number(rotationSetting) || 0;
        }

        const radians = (Math.abs(angle) * Math.PI) / 180;
        const xLabelHeight = angle === 0
            ? labelFontSize * 1.4
            : Math.min(maxXLabelWidth, h * 0.35) * Math.sin(radians) + labelFontSize * 1.3;
        const paddingBottom = xLabelHeight + 12 + (showXTitle ? titleSpace + 2 : 0);

        const plotLeft = Math.max(0, paddingLeft);
        const plotRight = w - Math.max(0, paddingRight);
        const plotTop = paddingTop;
        const plotBottom = h - paddingBottom;

        if (plotRight - plotLeft < 24 || plotBottom - plotTop < 24) {
            this.showMessage("视觉对象空间不足");
            return;
        }

        yScale.range([plotBottom, plotTop]);
        const y2Scale = d3.scaleLinear().domain([0, 100]).range([plotBottom, plotTop]);

        const innerPadding = clamp(s.bar.innerPadding.value, 0, 0.9);
        const xScale = d3.scaleBand<string>()
            .domain(rows.map((r) => r.uid))
            .range([plotLeft, plotRight])
            .paddingInner(innerPadding)
            .paddingOuter(Math.min(0.25, innerPadding / 2 + 0.02));

        const bandWidth = xScale.bandwidth();
        const step = xScale.step();

        // 类别数量过多时按步长抽稀 X 轴标签，保证可读性
        const labelUnit = angle === 0
            ? maxXLabelWidth + 6
            : (angle === 90 ? labelFontSize * 1.2 : labelFontSize * 1.7);
        const labelStep = bandWidth >= labelUnit || labelUnit <= 0
            ? 1
            : Math.ceil(labelUnit / Math.max(1, bandWidth));

        const barColor = s.bar.fill.value.value || "#3B6FE0";
        const barOpacity = 1 - clamp(s.bar.transparency.value, 0, 100) / 100;
        const borderRadius = clamp(s.bar.borderRadius.value, 0, 12);

        const lineColor = s.line.fill.value.value || "#ED7D31";
        const lineOpacity = 1 - clamp(s.line.transparency.value, 0, 100) / 100;
        const lineWidth = clamp(s.line.width.value, 0.5, 8);
        const lineDash = dashArray(String(s.line.dashType.value.value || "solid"), lineWidth);
        const smooth = s.line.smooth.value;
        const showMarkers = s.line.showMarkers.value;
        const markerSize = clamp(s.line.markerSize.value, 2, 16);

        // ---- 1) 网格线
        if (s.axisFormat.showGridlines.value) {
            const gridGroup = svgEl("g");
            const gridColor = s.axisFormat.gridlineColor.value.value || "#E1DFDD";
            const gridOpacity = 1 - clamp(s.axisFormat.gridlineTransparency.value, 0, 100) / 100;
            for (const tick of yTicks) {
                const y = yScale(tick);
                if (y < plotTop - 0.5 || y > plotBottom + 0.5) {
                    continue;
                }
                const lineEl = svgEl("line");
                setAttrs(lineEl, {
                    x1: plotLeft,
                    x2: plotRight,
                    y1: y,
                    y2: y,
                    stroke: gridColor,
                    "stroke-width": 1,
                    "stroke-opacity": gridOpacity,
                    "shape-rendering": "crispEdges"
                });
                gridGroup.appendChild(lineEl);
            }
            root.appendChild(gridGroup);
        }

        // ---- 2) 柱形
        const barsGroup = svgEl("g");
        const baselineY = yScale(0);
        root.appendChild(barsGroup);

        const centers: number[] = [];

        for (const row of rows) {
            const x = xScale(row.uid) || plotLeft;
            const centerX = x + bandWidth / 2;
            centers.push(centerX);

            const valueY = yScale(row.value);
            let barHeight = baselineY - valueY;
            let opacity = barOpacity;

            if (row.value <= 0) {
                // 0 值：绘制基线细条，提示该类别存在但不贡献占比
                barHeight = 2;
                opacity = barOpacity * 0.45;
            } else if (barHeight < 1) {
                barHeight = 1;
            }

            const rect = svgEl("rect");
            setAttrs(rect, {
                x: x,
                y: baselineY - barHeight,
                width: Math.max(0.5, bandWidth),
                height: barHeight,
                fill: barColor,
                "fill-opacity": opacity,
                rx: Math.min(borderRadius, bandWidth / 2),
                ry: Math.min(borderRadius, bandWidth / 2)
            });
            barsGroup.appendChild(rect);
            this.selectionPairs.push({ el: rect, id: row.selectionId });
        }

        // ---- 3) 柱顶数值标签
        if (s.bar.showValues.value) {
            const valueFontSize = clamp(s.bar.valueFontSize.value, 6, 24);
            const valueColor = s.bar.valueColor.value.value || "#323130";
            const valueGroup = svgEl("g");
            for (const row of rows) {
                const x = xScale(row.uid) || plotLeft;
                const valueY = yScale(row.value);
                const label = data.formatValue(row.value);
                const textEl = svgEl("text");
                setAttrs(textEl, {
                    x: x + bandWidth / 2,
                    y: Math.max(plotTop + valueFontSize, valueY - 5),
                    "text-anchor": "middle",
                    "font-family": FONT_FAMILY,
                    "font-size": valueFontSize,
                    fill: valueColor
                });
                textEl.textContent = label;
                valueGroup.appendChild(textEl);
            }
            root.appendChild(valueGroup);
        }

        // ---- 4) 参考线
        const refPercent = clamp(s.referenceLine.percent.value, 0, 100);
        const refCrossingXs: number[] = [];
        if (s.referenceLine.show.value) {
            const refColor = s.referenceLine.fill.value.value || "#C00000";
            const refOpacity = 1 - clamp(s.referenceLine.transparency.value, 0, 100) / 100;
            const refWidth = clamp(s.referenceLine.width.value, 0.5, 8);
            const refDash = dashArray(String(s.referenceLine.dashType.value.value || "dashed"), refWidth);
            const refY = y2Scale(refPercent);

            const refGroup = svgEl("g");

            const refLine = svgEl("line");
            setAttrs(refLine, {
                x1: plotLeft,
                x2: plotRight,
                y1: refY,
                y2: refY,
                stroke: refColor,
                "stroke-width": refWidth,
                "stroke-opacity": refOpacity,
                "stroke-dasharray": refDash,
                "shape-rendering": "crispEdges"
            });
            refGroup.appendChild(refLine);

            if (s.referenceLine.showLabel.value) {
                const labelText = `${Number(refPercent.toFixed(2))}%`;
                const labelEl = svgEl("text");
                setAttrs(labelEl, {
                    x: plotRight - 3,
                    y: refY - 5,
                    "text-anchor": "end",
                    "font-family": FONT_FAMILY,
                    "font-size": labelFontSize,
                    "font-weight": "600",
                    fill: refColor,
                    "fill-opacity": refOpacity
                });
                labelEl.textContent = labelText;
                refGroup.appendChild(labelEl);
            }

            // 记录累计折线与参考线的交点，稍后画在折线之上
            if (s.referenceLine.showMarkers.value) {
                for (let i = 0; i < rows.length; i++) {
                    const yCurrent = y2Scale(rows[i].cumulative * 100);
                    if (Math.abs(yCurrent - refY) < 0.6) {
                        refCrossingXs.push(centers[i]);
                    }
                    if (i === rows.length - 1) {
                        continue;
                    }
                    const yNext = y2Scale(rows[i + 1].cumulative * 100);
                    if ((yCurrent - refY) * (yNext - refY) < 0) {
                        const ratio = (refY - yCurrent) / (yNext - yCurrent);
                        refCrossingXs.push(centers[i] + ratio * (centers[i + 1] - centers[i]));
                    }
                }
            }

            root.appendChild(refGroup);
        }

        // ---- 5) 累计占比折线
        const points: [number, number][] = rows.map((row, index) => [
            centers[index],
            y2Scale(row.cumulative * 100)
        ]);

        const lineGroup = svgEl("g");
        const pathGenerator = d3.line<[number, number]>()
            .x((p) => p[0])
            .y((p) => p[1])
            .curve(smooth ? d3.curveMonotoneX : d3.curveLinear);

        const pathData = pathGenerator(points);
        if (pathData && points.length > 1) {
            const pathEl = svgEl("path");
            setAttrs(pathEl, {
                d: pathData,
                fill: "none",
                stroke: lineColor,
                "stroke-width": lineWidth,
                "stroke-opacity": lineOpacity,
                "stroke-dasharray": lineDash,
                "stroke-linejoin": "round",
                "stroke-linecap": "round"
            });
            lineGroup.appendChild(pathEl);
        }

        if (showMarkers || points.length === 1) {
            for (let i = 0; i < points.length; i++) {
                const marker = svgEl("circle");
                setAttrs(marker, {
                    cx: points[i][0],
                    cy: points[i][1],
                    r: showMarkers ? markerSize / 2 : 3,
                    fill: showMarkers ? lineColor : "none",
                    "fill-opacity": showMarkers ? lineOpacity : 0,
                    stroke: lineColor,
                    "stroke-width": 2,
                    "stroke-opacity": lineOpacity
                });
                lineGroup.appendChild(marker);
                this.selectionPairs.push({ el: marker, id: rows[i].selectionId });

                const row = rows[i];
                marker.addEventListener("mousemove", (event: MouseEvent) => {
                    this.showTooltip(event, row, rows.length, barColor);
                });
                marker.addEventListener("mouseleave", () => this.hideTooltip());
            }
        }
        root.appendChild(lineGroup);

        // ---- 5.1) 参考线交叉点标记（绘制在折线之上，确保可见）
        if (s.referenceLine.show.value && s.referenceLine.showMarkers.value && refCrossingXs.length > 0) {
            const refColor = s.referenceLine.fill.value.value || "#C00000";
            const refOpacity = 1 - clamp(s.referenceLine.transparency.value, 0, 100) / 100;
            const refY = y2Scale(refPercent);
            const crossGroup = svgEl("g");
            let lastX = Number.NaN;
            for (const cx of refCrossingXs) {
                if (!isNaN(lastX) && Math.abs(cx - lastX) < 2) {
                    continue;
                }
                lastX = cx;
                const dot = svgEl("circle");
                setAttrs(dot, {
                    cx: cx,
                    cy: refY,
                    r: 4.5,
                    fill: refColor,
                    "fill-opacity": refOpacity,
                    stroke: "#FFFFFF",
                    "stroke-width": 1.5
                });
                crossGroup.appendChild(dot);
            }
            root.appendChild(crossGroup);
        }

        // ---- 6) 坐标轴
        const axisGroup = svgEl("g");

        // X 轴基线
        const axisLine = svgEl("line");
        setAttrs(axisLine, {
            x1: plotLeft,
            x2: plotRight,
            y1: plotBottom,
            y2: plotBottom,
            stroke: "#C8C6C4",
            "stroke-width": 1,
            "shape-rendering": "crispEdges"
        });
        axisGroup.appendChild(axisLine);

        // Y 轴刻度标签
        for (let i = 0; i < yTicks.length; i++) {
            const y = yScale(yTicks[i]);
            if (y < plotTop - 0.5 || y > plotBottom + 0.5) {
                continue;
            }
            const textEl = svgEl("text");
            setAttrs(textEl, {
                x: plotLeft - 8,
                y: y,
                "text-anchor": "end",
                "dominant-baseline": "middle",
                "font-family": FONT_FAMILY,
                "font-size": labelFontSize,
                fill: labelColor
            });
            textEl.textContent = yTickLabels[i];
            axisGroup.appendChild(textEl);
        }

        // 辅助 Y 轴（0% - 100%）
        if (showY2Axis) {
            for (let i = 0; i < y2TickLabels.length; i++) {
                const textEl = svgEl("text");
                setAttrs(textEl, {
                    x: plotRight + 8,
                    y: y2Scale(i * 20),
                    "text-anchor": "start",
                    "dominant-baseline": "middle",
                    "font-family": FONT_FAMILY,
                    "font-size": labelFontSize,
                    fill: labelColor
                });
                textEl.textContent = y2TickLabels[i];
                axisGroup.appendChild(textEl);
            }
        }

        // X 轴刻度标签
        for (let i = 0; i < rows.length; i++) {
            if (labelStep > 1 && i % labelStep !== 0) {
                continue;
            }
            const cx = centers[i];
            const textEl = svgEl("text");
            if (angle === 0) {
                setAttrs(textEl, {
                    x: cx,
                    y: plotBottom + 5,
                    "text-anchor": "middle",
                    "dominant-baseline": "hanging",
                    "font-family": FONT_FAMILY,
                    "font-size": labelFontSize,
                    fill: labelColor
                });
            } else {
                setAttrs(textEl, {
                    transform: `translate(${cx},${plotBottom + 5}) rotate(${-angle})`,
                    "text-anchor": "end",
                    dy: "0.35em",
                    "font-family": FONT_FAMILY,
                    "font-size": labelFontSize,
                    fill: labelColor
                });
            }
            textEl.textContent = rows[i].label;
            axisGroup.appendChild(textEl);
        }

        root.appendChild(axisGroup);

        // ---- 7) 坐标轴标题
        if (showXTitle || showYTitle || showY2Title) {
            const titleGroup = svgEl("g");
            const centerY = (plotTop + plotBottom) / 2;

            if (showXTitle) {
                const textEl = svgEl("text");
                setAttrs(textEl, {
                    x: (plotLeft + plotRight) / 2,
                    y: h - 4,
                    "text-anchor": "middle",
                    "font-family": FONT_FAMILY,
                    "font-size": titleFontSize,
                    "font-weight": titleWeight,
                    fill: titleColor
                });
                textEl.textContent = xTitleText;
                titleGroup.appendChild(textEl);
            }

            if (showYTitle) {
                const textEl = svgEl("text");
                setAttrs(textEl, {
                    transform: `translate(${titleFontSize * 1.4},${centerY}) rotate(-90)`,
                    "text-anchor": "middle",
                    "dominant-baseline": "middle",
                    "font-family": FONT_FAMILY,
                    "font-size": titleFontSize,
                    "font-weight": titleWeight,
                    fill: titleColor
                });
                textEl.textContent = yTitleText;
                titleGroup.appendChild(textEl);
            }

            if (showY2Title) {
                const textEl = svgEl("text");
                setAttrs(textEl, {
                    transform: `translate(${w - titleFontSize * 1.4},${centerY}) rotate(90)`,
                    "text-anchor": "middle",
                    "dominant-baseline": "middle",
                    "font-family": FONT_FAMILY,
                    "font-size": titleFontSize,
                    "font-weight": titleWeight,
                    fill: titleColor
                });
                textEl.textContent = y2TitleText;
                titleGroup.appendChild(textEl);
            }

            root.appendChild(titleGroup);
        }

        // ---- 8) 交互热区（覆盖整列，便于悬停与点击）
        const hitGroup = svgEl("g");
        const hitTop = plotTop;
        const hitHeight = Math.max(0, plotBottom - plotTop);
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const centerX = centers[i];
            const halfStep = Math.max(bandWidth, step) / 2;
            const xLeft = Math.max(plotLeft, centerX - halfStep);
            const xRight = Math.min(plotRight, centerX + halfStep);

            const hit = svgEl("rect");
            setAttrs(hit, {
                x: xLeft,
                y: hitTop,
                width: Math.max(1, xRight - xLeft),
                height: hitHeight,
                fill: "transparent",
                style: "cursor:pointer"
            });

            hit.addEventListener("mousemove", (event: MouseEvent) => {
                this.showTooltip(event, row, rows.length, barColor);
            });
            hit.addEventListener("mouseleave", () => this.hideTooltip());
            hit.addEventListener("click", (event: MouseEvent) => {
                event.stopPropagation();
                const multi = event.ctrlKey || event.metaKey || event.shiftKey;
                this.selectionManager.select(row.selectionId, multi).then(() => {
                    this.applySelectionStyles();
                });
            });
            hit.addEventListener("contextmenu", (event: MouseEvent) => {
                event.preventDefault();
                event.stopPropagation();
                const position = this.getRelativePosition(event);
                this.selectionManager.showContextMenu(row.selectionId, {
                    x: position[0],
                    y: position[1]
                });
            });

            hitGroup.appendChild(hit);
        }
        root.appendChild(hitGroup);

        // ---- 9) 数据处理提示（绘制在绘图区上方，绝不遮挡数据）
        if (notice) {
            const noticeFontSize = 9;
            const noticeText = svgEl("text");
            setAttrs(noticeText, {
                x: plotLeft,
                y: Math.max(10, plotTop - 8),
                "text-anchor": "start",
                "dominant-baseline": "middle",
                "font-family": FONT_FAMILY,
                "font-size": noticeFontSize,
                fill: notice.warning ? "#A4262C" : "#8A8886",
                style: "pointer-events:none"
            });
            noticeText.textContent = notice.text;
            root.appendChild(noticeText);
        }

        this.applySelectionStyles();
    }

    // ---------------------------------------------------------------- 交互

    private getRelativePosition(event: MouseEvent): number[] {
        const rect = this.container.getBoundingClientRect();
        return [event.clientX - rect.left, event.clientY - rect.top];
    }

    private showTooltip(event: MouseEvent, row: ParetoDatum, count: number, barColor: string): void {
        if (!this.tooltipService || !this.tooltipService.enabled() || !this.currentData) {
            return;
        }

        const items: powerbi.extensibility.VisualTooltipDataItem[] = [
            { displayName: "类别", value: row.label },
            { displayName: "当前值", value: this.currentData.formatValue(row.value), color: barColor },
            { displayName: "占比", value: formatPercent(row.share) },
            { displayName: "累计占比", value: formatPercent(row.cumulative) },
            { displayName: "排名", value: `第 ${row.rank} / ${count} 位` }
        ];

        if (row.rawValue !== null && row.rawValue !== undefined && row.rawValue !== row.value) {
            items.push({ displayName: "原始值", value: this.currentData.formatValue(row.rawValue) });
        }
        if (row.note) {
            items.push({ displayName: "说明", value: row.note });
        }

        this.tooltipService.show({
            dataItems: items,
            identities: [row.selectionId],
            coordinates: this.getRelativePosition(event),
            isTouchEvent: false
        });
    }

    private hideTooltip(): void {
        if (this.tooltipService && this.tooltipService.enabled()) {
            this.tooltipService.hide({ immediately: false, isTouchEvent: false });
        }
    }

    private applySelectionStyles(): void {
        const hasSelection = this.selectionManager.hasSelection();
        const selectedIds = hasSelection ? this.selectionManager.getSelectionIds() : [];

        for (const pair of this.selectionPairs) {
            const isSelected = !hasSelection || selectedIds.some((id) => (id as any).equals(pair.id));
            pair.el.setAttribute("opacity", isSelected ? "1" : "0.35");
        }
    }

    // ---------------------------------------------------------------- 占位与提示

    private buildNotice(data: ParetoData): { text: string; warning: boolean } | null {
        if (!this.settings.dataHandling.showNotice.value) {
            return null;
        }

        if (!data.hasTotal) {
            return { text: "合计为 0，累计占比无法计算", warning: true };
        }

        const parts: string[] = [];
        if (data.stats.blanks > 0) {
            parts.push(`空值 ${data.stats.blanks}`);
        }
        if (data.stats.negatives > 0) {
            parts.push(`负数 ${data.stats.negatives}`);
        }
        if (data.stats.droppedZeros > 0) {
            parts.push(`0 值 ${data.stats.droppedZeros}`);
        }

        if (parts.length === 0) {
            return null;
        }

        return { text: `已处理 ${parts.join(" · ")}`, warning: false };
    }

    private showMessage(message: string): void {
        this.emptyEl.textContent = message;
        this.emptyEl.style.display = "flex";
    }

    private clearAll(): void {
        while (this.svg.firstChild) {
            this.svg.removeChild(this.svg.firstChild);
        }
        this.selectionPairs = [];
        this.currentData = null;
        this.emptyEl.style.display = "none";
        this.emptyEl.textContent = "";
    }
}
